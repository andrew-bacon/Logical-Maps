# Open questions — Classicism

Conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (7)

#### □Strong Leibniz Biconditionals ∧ Rigid Comprehension ⇒ □BF (relational types) — `necessary-strong-leibniz-and-rigid-comprehension-imply-necessary-bf-relational`

**Answer: Open.**

Original record notes:

Downgraded from proved to conjectured on 11 October 2026, at Cian Dorr's request. The proof of Theorem 8.2 in the book has a gap, found while formalizing it in Lean and confirmed by Cian Dorr; the write-up sets out the book's argument with the gap marked. The argument proves $\forall p\,.\,Wp\to p=r$ at the evaluation point and then boxes it as following "from necessary assumptions". But step (i), that a $W$-proposition $p$ falls under some member of $H$ at every world, uses the claim that the world property $U=\lambda q\,.\,v\land q=p$ is $H$ because it is a world property accessible to $W$; that holds at the evaluation point, where $H$ is coextensive with the accessible world properties, but at another world $H$ is known only to be rigid, and need not contain the world properties built there from that world's $v$ and $p$. The step is needed exactly at such worlds, since $W$ may have no actual instance. Boxing Rigid Comprehension does not obviously help, since $r$ must be defined from a single actual $H$. What would settle the conjecture: a repair of step (i), or a model of C with □Strong Leibniz and Rigid Comprehension in which BF fails at some relational type. No recorded model refutes it, and without this record the map does not derive it. With □Rigid Comprehension and Rigid Power in place of Rigid Comprehension the conclusion holds (strong-leibniz-necessary-rigid-comprehension-and-rigid-power-imply-bf-relational, Cian Dorr), so a countermodel must fail one of those. The converse half of Theorem 8.2, atomicity-and-bf-relational-imply-strong-leibniz and its boxed form, is unaffected.

- **Philosophical Introduction to HOL** — Andrew Bacon, A Philosophical Introduction to Higher-Order Logics, Routledge, 2024, §8.2, Theorem 8.2, pp. 169–171.

Record: `topics/classicism/results/necessary-strong-leibniz-and-rigid-comprehension-imply-necessary-bf-relational.yaml`.

#### Possible Infinity (type t) ⇒ Axiom of Infinity (type t) — `possible-infinity-t-implies-axiom-of-infinity-t`

**Answer: Open.**

Original record notes:

Equivalent to the claim that a finite count of propositions is necessary whenever it is true. It holds with No Pure Contingency and with BF (type $t$), by the recorded results. If some finite $Z$ holds of $\lambda p\, .\,\top$ then every proposition is one of finitely many, and NI carries each identity across, but collecting them under a box is an instance of BF at type $t$, which C does not prove. A proof would need to bypass that; a countermodel would need a world with finitely many propositions that can see one with more, and must violate both BF (type $t$) and No Pure Contingency.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-t-implies-axiom-of-infinity-t.yaml`.

#### Relational Choice ∧ Boolean Completeness ⇒ Transversal Choice — `relational-choice-and-boolean-completeness-imply-transversal-choice`

**Answer: Open.**

Original record notes:

Does adding Boolean Completeness to Relational Choice suffice for Transversal Choice in C? The question without Boolean Completeness is recorded separately. No proof was supplied. A proof of this implication, or a model of C satisfying both premises and failing Transversal Choice, would settle this conjecture.

- **Goodsell 27 Sep** — Zachary Goodsell, conjecture communicated on 27 September 2026: Relational Choice + Boolean Completeness ⊢ Transversal Choice.

Record: `topics/classicism/results/relational-choice-and-boolean-completeness-imply-transversal-choice.yaml`.

#### Relational Choice ⇒ Transversal Choice — `relational-choice-r-implies-transversal-choice-r`

**Answer: Open.**

Original record notes:

Does Relational Choice alone give a transversal for every equivalence relation? Christopher Sun observed that the literature claims this without proof. The converse is recorded. The quotient argument chooses from each cell $\lambda z\, .\,(Rx)z$ and needs the cells of two members of one class to be the same property; in C that is necessary coextension, and the hypothesis gives actual coextension only. No definable substitute for the cell helps, since an operation definable from $R$ identifies $x$ with $x'$ only when they are necessarily indiscernible with respect to $R$. A Zermelo-style well-ordering argument breaks at the same point: coextensive but distinct stages receive different chosen elements. The expectation is that the implication fails. What would settle it: a proof that uses the chosen relation to break the symmetry between coextensive cells, or a model of C with Relational Choice that is not extensionally full at its evaluation point. Every recorded model of Relational Choice is extensionally full there, in that every set of tuples from the domains is the extension of a rigid element, and that fullness verifies Transversal Choice by the same metatheoretic choice, so none separates the two. Symmetric Henkin models in the Fraenkel–Mostowski style cannot separate them either; see the write-up.
Update of 28 September 2026: Christopher Sun showed on 26 September that Transversal Choice is equivalent to Relational Choice together with Transversal (transversal-and-relational-choice-imply-transversal-choice), so this question is equivalent to whether Relational Choice implies Transversal. Anything that implies Transversal, such as Actuality, closes the gap.

- **Sun via Goodsell 25 Sep** — Christopher Sun, observation communicated by Zachary Goodsell on 25 September 2026, that the transversal formulation of choice is claimed in the literature without a proof from Relational Choice.

Record: `topics/classicism/results/relational-choice-r-implies-transversal-choice-r.yaml`.

#### Rigid Rigidity ⇒ Rigid Power — `rigid-rigidity-implies-rigid-power`

**Answer: Open.**

Original record notes:

Cian Dorr proposed it on 10 October 2026, with an argument that assumed rigidity is closed under conjunction. It is not, in C: if $x\ne y$ but possibly $x=y$, the conjunction of their haecceities is persistent but not weakly inextensible, since weak inextensibility would require $\Box\,x\ne y$. Under □ND conjunctions of rigid relations are rigid and the argument goes through, but C5 already gives □Rigid Power. A countermodel must therefore have contingent identity at some accessible world: a rigid $Y$ not below a rigid $X$ that comes below it at an accessible world by identifications, without becoming identical there to any rigid subrelation of $X$ at the evaluation point. With the recorded results, the conjecture would make Rigid Rigidity equivalent to □BF + Rigid Power, and Weakly Rigid Weak Rigidity equivalent to BF + Weakly Rigid Power. Since Rigid Rigidity implies its necessitation, the conjecture is equivalent to Rigid Rigidity ⇒ □Rigid Power.

- **Dorr 10 Oct** — Cian Dorr, conjecture of 10 October 2026.

Record: `topics/classicism/results/rigid-rigidity-implies-rigid-power.yaml`.

#### Strong Possibility (signature Σ) ⇒ Strong Possibility (pure) — `strong-possibility-signature-r-implies-strong-possibility-r`

**Answer: Open.**

Original record notes:

The restriction of the signature schema to pure P gives ◇≠P for every pure P consistent with Max(C(Σ)); the pure schema asks for every pure P consistent with Max(C). So the arrow holds iff Max(C(Σ)), equivalently Max(C) plus Separated Structure, is conservative over Max(C) for pure sentences: every pure sentence consistent with Pure Maximalist Classicism must remain consistent when Separated Structure is added. Adjoining constants is conservative for C, which is why Possibility Maximalism (signature Σ) implies Possibility Maximalism (pure), but for the maximalization a model of Max(C) + P would need its constants interpreted so that each realizes every consistent role at some truncation, which is not automatic. A proof of that conservativity, or a pure sentence consistent with Max(C) but not with Max(C) + Separated Structure, would settle it.

- **Dorr 22 Sep** — Cian Dorr, suggestion of 22 September 2026.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, p. 39; §2.6, p. 42.

Record: `topics/classicism/results/strong-possibility-signature-r-implies-strong-possibility-r.yaml`.

#### Tame Rigidity ∧ Rigid Power ⇒ Weakly Rigid Power — `tame-rigidity-and-rigid-power-imply-weakly-rigid-power`

**Answer: Open.**

Original record notes:

The converse of weakly-rigid-power-implies-tame-rigidity and weakly-rigid-power-implies-rigid-power. With □Tame Rigidity in place of Tame Rigidity it is proved (necessary-tame-rigidity-and-rigid-power-imply-weakly-rigid-power). The unboxed argument fails at weak inextensibility: for weakly rigid $F$, $P_F:=\lambda X\, .\,\operatorname{WeaklyRigid}(X)\land X\le F$ is weakly persistent, but $Z:=\lambda X\, .\,\operatorname{Rigid}(X)\land X\le F$ satisfies $\forall X\, .\,P_FX\to\Box ZX$, so the weak inextensibility of $P_F$ requires $P_F\le Z$, which is Tame Rigidity below $F$ at every accessible world. Weakly Rigid Power implies □Tame Rigidity at type $t$ (and, with BF, at every type: barcan-and-weakly-rigid-power-imply-necessary-tame-rigidity), so the conjecture would follow from Tame Rigidity + Rigid Power ⇒ □Tame Rigidity, and a countermodel must satisfy Tame Rigidity and Rigid Power while failing □Tame Rigidity at type $t$. No recorded model yet separates Tame Rigidity from □Tame Rigidity.

- **Dorr 10 Oct** — Cian Dorr, question of 10 October 2026.

Record: `topics/classicism/results/tame-rigidity-and-rigid-power-imply-weakly-rigid-power.yaml`.

### 1.2 Resolved (76)

#### Actuality ∧ BF ⇒ Inextensible Comprehension — `actuality-and-bf-imply-inextensible-comprehension`

**Answer: Proved.**

Supporting result ids: `actuality-and-bf-imply-inextensible-comprehension`.

Original record notes:

BF is used only at the actual world, at the type $\bar\sigma t$ of $X$ and at the argument types $\bar\sigma$, to bring the quantifiers in the negated leading box of inextensibility out to the actual world, where Actuality can be applied to the chosen instances. This strengthens the earlier result from □BF and Actuality, which now follows from it. The identifier was first used on 26 September 2026 for this claim as a conjecture, which was withdrawn the same day because the recorded argument then needed □BF.

- **Sun, 26 Sep** — Christopher Sun, argument communicated to Cian Dorr on 26 September 2026 and reported by him on 27 September 2026; see the write-up.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 28–30 (inextensibility); Proposition 2.1, pp. 20–21 (BF).

Record: `topics/classicism/results/actuality-and-bf-imply-inextensible-comprehension.yaml`.

#### □ND ∧ Atomicity ⇒ No Pure Contingency — `c5-and-atomicity-imply-no-pure-contingency`

**Answer: Proved.**

Supporting result ids: `c5-and-atomicity-imply-no-pure-contingency`.

Original record notes:

Reported by the source as a theorem of Goodsell and Yli-Vakkuri, without a proof; recorded as conjectured on 17 September 2026 pending verification, and promoted on 23 September 2026 with an independent proof, sketched by Cian Dorr with permission from Zachary Goodsell. Only the type-t instance of Atomicity is used; the record c5-and-atomicity-t-imply-no-pure-contingency states that sharper form and this record is derivable from it. □ND is used through ND (rigidity of identity propositions at each type) and BF (commutation of the atom-exchanging automorphism with the quantifiers, and rigidity of the hypothesis that the two atoms are distinct).

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 27.
- **Dorr 23 Sep** — Cian Dorr, proof sketch of 23 September 2026, with permission from Zachary Goodsell; written out in the write-up.

Record: `topics/classicism/results/c5-and-atomicity-imply-no-pure-contingency.yaml`.

#### Maximalism (pure) ∧ Rigid Comprehension ⇒ ⊥ — `maximalist-distinctness-incompatible-with-rigid-comprehension`

**Answer: Proved.**

Supporting result ids: `maximalist-distinctness-incompatible-with-rigid-comprehension`.

Original record notes:

Recorded on 17 September 2026 as a reported theorem awaiting a supplied proof. The proof is now Goodsell's own, imported from Arithmetic is Necessary, and the record is derivable from the recorded chain through Boolean Completeness, Countable Boolean Completeness and the Necessity of Arithmetic.

- **Arithmetic is Necessary** — Zachary Goodsell, Arithmetic is Necessary, draft of 5 June 2024, §6, Theorem 11 and the remark following it, p. 25.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-rigid-comprehension.yaml`.

#### □Atomicity ∧ Boolean Completeness ∧ BF ⇒ Rigid Comprehension — `necessary-atomicity-completeness-bf-imply-rigid-comprehension`

**Answer: Refuted.**

Supporting result ids: `necessary-boolean-completeness-r-implies-boolean-completeness-r`, `necessary-barcan-r-implies-barcan-r`.

Model witness ids: `ultralimit-fork`.

Original record notes:

Downgraded from proved to conjectured on 28 September 2026, at Cian Dorr's request. The source's proof (Proposition 2.11, note 42) has two gaps, found that day by an agent working in the Lean-Classicism formalization project; the write-up sets out the paper's argument with the gaps marked. (a) Part (iv) of note 42 boxes a claim that holds pointwise in the object variables by BF, where □BF would be needed. Cian Dorr agreed. (b) The same part's "without loss of generality" step replaces the atom $w'$ by $w''$, the greatest lower bound of the propositions $p$ with $w\le(p=w')$. The proof then needs $w\le(w''=w')$, so that $w''$ is still possible and below $X^*z\land\neg Yz$ where $w$ holds; nothing in the premises gives this, and □BF does not help. A propositional structure in which that step fails is sketched in the project's VERIFICATION.md; it has not been extended to a model of C with all the premises, so it shows that the step needs an argument, not that the proposition is false. What is proved there: Actuality, Boolean Completeness and BF (at the relevant types), together with a restriction principle, give Rigid Comprehension with the paper's witness $X^*$. The restriction principle says that for all $p,q$ there is an $r$ with $p\le(r=q)$ such that $r\le s$ whenever $p\le(q\le s)$. It holds in C5, with $r:=q\land\Diamond p$. Restructured this way, gap (a) disappears, and gap (b) becomes the question whether the premises here give the restriction principle. What would settle the conjecture: a derivation of the restriction principle, or another argument, from boxed Atomicity, Boolean Completeness and BF; or a model of C with those three principles that fails Rigid Comprehension. The source's first cross-reference to Proposition 2.6 was replaced in the earlier transcription by Proposition 2.7; the statement and premises are unchanged.

Refuted, 1 October 2026: the model ultralimit-fork, from Branden Fitelson (with Claude and GPT-6 Astra), satisfies Classicism, □Atomicity, □Boolean Completeness, □BF and □Actuality, and fails Rigid Comprehension at type $t\to t$. It extends the propositional structure mentioned above to a model of C with all the premises, so gap (b) is a genuine gap. The record stays conjectured, as the map's convention requires; the model is the refuting evidence. Gap-free in the end is part (ii), which gets Actuality: Atomicity (type $t$) and Weak Inextensible Comprehension imply Actuality (atomicity-t-and-weakly-inextensible-comprehension-imply-actuality), and Boolean Completeness implies Weak Inextensible Comprehension.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.11, p. 30 and n. 42.

Record: `topics/classicism/results/necessary-atomicity-completeness-bf-imply-rigid-comprehension.yaml`.

#### Possible Infinity (type e) ⇒ Axiom of Infinity (type e) — `possible-infinity-e-implies-axiom-of-infinity-e`

**Answer: Refuted.**

Supporting result ids: `possibility-plus-r-implies-possibility-schema-r`, `possibility-schema-r-implies-possible-infinity-e`, `axiom-of-infinity-e-implies-infinity-e`.

Model witness ids: `coalesced-single-individual-root`.

Original record notes:

Equivalent to the claim that a finite count of individuals is necessary whenever it is true. It holds with No Pure Contingency and with BF, by the recorded results. A countermodel would need a world with finitely many individuals that can see one with more, and must violate both BF at type $e$ and No Pure Contingency; the coalesced sums on the map do not supply one, since their roots have infinitely many individuals.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-e-implies-axiom-of-infinity-e.yaml`.

#### Coalesced sum: maximalist root — `coalesced-maximalist-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-vicinity`, `maximalist-distinctness-incompatible-with-necessary-weakly-inextensible-comprehension-r`, `maximalist-distinctness-incompatible-with-necessary-transversal-r`.

Model witness ids: `coalesced-maximalist-root`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Theorem 3.26, §§3.6, pp. 62–64; Appendix E, pp. 80–83; §2.6, p. 41.

Record: `topics/classicism/models/coalesced-maximalist-root.yaml`.

#### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possibility-plus-r-implies-possibility-schema-r`, `maximalist-distinctness-incompatible-with-necessary-vicinity`, `maximalist-distinctness-incompatible-with-necessary-weakly-inextensible-comprehension-r`, `maximalist-distinctness-incompatible-with-necessary-transversal-r`.

Model witness ids: `coalesced-single-individual-root`.

Original record notes:

Promoted on 22 September 2026 for the pure package, which the source establishes; the earlier conjectured status concerned an expansion to the map’s signature Σ. That expansion exists exactly when Σ has at most one individual constant: with two, the unique root individual would have to be carried to two different interpretations in a component where they differ, which no arrow can do. So the signature principles are not listed; for a signature with individual constants see the constant-indexed root.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, pp. 41–42 and n. 61; Appendix E, p. 83.

Record: `topics/classicism/models/coalesced-single-individual-root.yaml`.

#### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-intensional-choice-incompatible`.

Model witness ids: `finite-support-dyadic-roundings`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: dyadic roundings of N [Σ true atom] — `finite-support-dyadic-roundings-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-intensional-choice-incompatible`.

Model witness ids: `finite-support-dyadic-roundings-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: dyadic roundings of N [one individual] — `finite-support-dyadic-roundings-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-dyadic-roundings-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: dyadic roundings of N [one individual; Σ true atom] — `finite-support-dyadic-roundings-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-dyadic-roundings-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-t-and-bf-imply-atomicity`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `barcan-r-implies-barcan-t`, `no-pure-contingency-and-bf-t-imply-necessary-bf-t`, `possibility-and-necessary-barcan-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections [Σ true atom] — `finite-support-identity-or-collapse-surjections-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-t-and-bf-imply-atomicity`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `barcan-r-implies-barcan-t`, `no-pure-contingency-and-bf-t-imply-necessary-bf-t`, `possibility-and-necessary-barcan-t-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-surjections-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections [one individual] — `finite-support-identity-or-collapse-surjections-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-t-and-bf-imply-atomicity`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-surjections-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections [one individual; Σ true atom] — `finite-support-identity-or-collapse-surjections-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-t-and-bf-imply-atomicity`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-surjections-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-intensional-choice-incompatible`.

Model witness ids: `finite-support-identity-or-collapse`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps [Σ true atom] — `finite-support-identity-or-collapse-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-intensional-choice-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps [one individual] — `finite-support-identity-or-collapse-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps [one individual; Σ true atom] — `finite-support-identity-or-collapse-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-identity-or-collapse-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `finite-support-monotone-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source notes that with all maps BF would still hold, since every map agrees on any finite set with a surjection; monotonicity is what makes it fail.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone maps of N [Σ top] — `finite-support-monotone-maps-sigma-top`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-intensional-choice-incompatible`.

Model witness ids: `finite-support-monotone-maps-sigma-top`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source notes that with all maps BF would still hold, since every map agrees on any finite set with a surjection; monotonicity is what makes it fail.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone maps of N [one individual] — `finite-support-monotone-maps-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`.

Model witness ids: `finite-support-monotone-maps-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source notes that with all maps BF would still hold, since every map agrees on any finite set with a surjection; monotonicity is what makes it fail.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone maps of N [one individual; Σ top] — `finite-support-monotone-maps-individuals-singleton-sigma-top`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-monotone-maps-individuals-singleton-sigma-top`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source notes that with all maps BF would still hold, since every map agrees on any finite set with a surjection; monotonicity is what makes it fail.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `barcan-r-implies-barcan-t`, `no-pure-contingency-and-bf-t-imply-necessary-bf-t`, `possibility-and-necessary-barcan-t-incompatible`.

Model witness ids: `finite-support-monotone-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 2, pp. 74, 76–77; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-monotone-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

#### Finite-support action model: monotone surjections of N [one individual] — `finite-support-monotone-surjections-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-monotone-surjections-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 2, pp. 74, 76–77; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-monotone-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

#### Finite-support action model: permutations of N — `finite-support-permutations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-weakly-inextensible-comprehension-imply-actuality`, `actuality-incompatible-with-atomlessness`, `boolean-completeness-r-implies-weakly-inextensible-comprehension-r`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `finite-support-permutations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source derives the failure of Boolean Completeness through C5 and the failure of Actuality (Propositions 2.5–2.6), which gives nothing about countable families.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 1, pp. 74–76; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-permutations.yaml`.

#### Finite-support action model: permutations of N [one individual] — `finite-support-permutations-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-weakly-inextensible-comprehension-imply-actuality`, `actuality-incompatible-with-atomlessness`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `finite-support-permutations-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. The source derives the failure of Boolean Completeness through C5 and the failure of Actuality (Propositions 2.5–2.6), which gives nothing about countable families.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 1, pp. 74–76; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-permutations.yaml`.

#### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `atomicity-and-bf-imply-necessary-actuality`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `finite-support-truncated-shifts`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncated shifts of N [Σ true atom] — `finite-support-truncated-shifts-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `atomicity-and-bf-imply-necessary-actuality`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `finite-support-truncated-shifts-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncated shifts of N [one individual] — `finite-support-truncated-shifts-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `atomicity-and-bf-imply-necessary-actuality`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `finite-support-truncated-shifts-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncated shifts of N [one individual; Σ true atom] — `finite-support-truncated-shifts-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `atomicity-and-bf-imply-necessary-actuality`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `finite-support-truncated-shifts-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncations of N — `finite-support-truncations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `boolean-completeness-r-implies-weakly-inextensible-comprehension-r`, `atomicity-t-and-weakly-inextensible-comprehension-imply-actuality`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-intensional-choice-incompatible`.

Model witness ids: `finite-support-truncations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Even the universal property has no inextensible coextension, since $\operatorname{Inextensible}(\top_{et})$ unfolds to $\Box$BF at type $e$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 6, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/finite-support-truncations.yaml`.

#### Finite-support action model: truncations of N [one individual] — `finite-support-truncations-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `finite-support-truncations-individuals-singleton`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Even the universal property has no inextensible coextension, since $\operatorname{Inextensible}(\top_{et})$ unfolds to $\Box$BF at type $e$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 6, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/finite-support-truncations.yaml`.

#### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `signature-b-and-witnessed-possibility-incompatible`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-necessary-intensional-choice-incompatible`.

Model witness ids: `finite-support-two-object-all-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, paragraph beginning “One particularly interesting result”.

Record: `topics/classicism/models/finite-support-two-object-all-maps.yaml`.

#### Full action model: free monoid on countably many generators, glued constants, thread individuals — `full-free-monoid-glued-constants`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Model witness ids: `full-free-monoid-glued-constants`.

Original record notes:

Promoted from conjectured on 22 September 2026. The gap in the source was its Theorem A.8, stated without proof, and the deferred type-e case; the write-up closes both by choosing a self-similar individual domain and applying the book’s coalesced sums. The signature is assumed countable; for a larger signature use a tree with as many branches. Distinct constants of one type denote distinct entities at the root, since every domain, including the individuals, has more than one element; they are also possibly identical. Everything else follows from the listed principles by the map’s results. Bacon’s interpretation of his predicates Pure and Fun in this model, and the principles stated with them, are not recorded, following Zachary Goodsell’s decision to keep the map to the logical vocabulary and the constants of Σ.

- **Logical Combinatorialism** — Andrew Bacon, Logical Combinatorialism, Philosophical Review 129 (2020), Appendix A.2–A.3, pp. 580–587; §2, n. 15, p. 547; §4, n. 48, p. 566.
- **Philosophical Introduction to HOL** — Andrew Bacon, A Philosophical Introduction to Higher-Order Logics, Routledge, 2024, §18.1, Definition 18.1, pp. 391–392; §18.3, Definition 18.6, p. 395; §18.6, Definitions 18.14–18.15, Proposition 18.7, Theorem 18.5 and Exercise 18.23, pp. 405–410.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.4–3.5, pp. 55–61 (full action models and the principles they validate); Appendix E, pp. 80–83 (truncations).
- **Fable 22 Sep** — Claude Fable 5.1 (Anthropic), verification of 22 September 2026 (see the write-up).

Record: `topics/classicism/models/full-free-monoid-glued-constants.yaml`.

#### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `no-pure-contingency-and-bf-imply-necessary-bf`.

Model witness ids: `full-idempotent-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [Σ true atom] — `full-idempotent-monoid-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `possible-infinity-e-and-no-pure-contingency-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `no-pure-contingency-and-bf-imply-necessary-bf`.

Model witness ids: `full-idempotent-monoid-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals] — `full-idempotent-monoid-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `no-pure-contingency-and-bf-imply-necessary-bf`.

Model witness ids: `full-idempotent-monoid-individuals-fixed-infinite`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; ZF + socks] — `full-idempotent-monoid-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `no-pure-contingency-and-bf-imply-necessary-bf`.

Model witness ids: `full-idempotent-monoid-individuals-fixed-infinite-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; Σ true atom] — `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `no-pure-contingency-and-bf-imply-necessary-bf`.

Model witness ids: `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `no-pure-contingency-and-bf-imply-necessary-bf`.

Model witness ids: `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: two-element group — `full-involution-group`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `gallin-comprehension-implies-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [Σ true atom] — `full-involution-group-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [infinitely many fixed individuals] — `full-involution-group-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `gallin-comprehension-implies-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-individuals-fixed-infinite`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [infinitely many fixed individuals; ZF + socks] — `full-involution-group-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `gallin-comprehension-implies-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-individuals-fixed-infinite-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [infinitely many fixed individuals; Σ true atom] — `full-involution-group-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: two-element group [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-involution-group-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-involution-group-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: surjections of an infinite set — `full-surjection-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-incompatible-with-infinity-t`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`.

Model witness ids: `full-surjection-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-metatheory-no-countable-choice-reals`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-barcan-r-implies-barcan-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `bf-weak-rigid-comprehension-atomicity-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`.

Model witness ids: `full-surjection-monoid-metatheory-no-countable-choice-reals`, `full-surjection-monoid-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [ZF + socks] — `full-surjection-monoid-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-barcan-r-implies-barcan-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `bf-weak-rigid-comprehension-atomicity-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`.

Model witness ids: `full-surjection-monoid-metatheory-no-countable-choice-reals`, `full-surjection-monoid-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [Σ true atom] — `full-surjection-monoid-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-incompatible-with-infinity-t`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-signature-b-r`.

Model witness ids: `full-surjection-monoid-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-sigma-true-atom-metatheory-no-countable-choice-reals`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-barcan-r-implies-barcan-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `bf-weak-rigid-comprehension-atomicity-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-signature-b-r`.

Model witness ids: `full-surjection-monoid-sigma-true-atom-metatheory-no-countable-choice-reals`, `full-surjection-monoid-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [Σ true atom; ZF + socks] — `full-surjection-monoid-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-barcan-r-implies-barcan-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `bf-weak-rigid-comprehension-atomicity-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-signature-b-r`.

Model witness ids: `full-surjection-monoid-sigma-true-atom-metatheory-no-countable-choice-reals`, `full-surjection-monoid-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals] — `full-surjection-monoid-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-incompatible-with-infinity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-individuals-fixed-infinite-metatheory-no-countable-choice-reals`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-barcan-r-implies-barcan-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `bf-weak-rigid-comprehension-atomicity-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-metatheory-no-countable-choice-reals`, `full-surjection-monoid-individuals-fixed-infinite-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; ZF + socks] — `full-surjection-monoid-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-barcan-r-implies-barcan-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `bf-weak-rigid-comprehension-atomicity-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-metatheory-no-countable-choice-reals`, `full-surjection-monoid-individuals-fixed-infinite-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-incompatible-with-infinity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-signature-b-r`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-barcan-r-implies-barcan-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `bf-weak-rigid-comprehension-atomicity-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-signature-b-r`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`, `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-barcan-r-implies-barcan-r`, `necessary-rigid-comprehension-implies-necessary-weak-rigid-comprehension`, `necessary-weak-rigid-comprehension-r-implies-weak-rigid-comprehension-r`, `bf-weak-rigid-comprehension-atomicity-and-relational-choice-imply-intensional-choice`, `fregean-incompatible-with-infinity-t`, `no-contingency-signature-r-implies-signature-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-signature-b-r`.

Model witness ids: `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`, `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The source takes infinitely many individuals with a surjective action, such as the surjections' action on the set by evaluation. That action gives, on the map's principles, what the variant with infinitely many fixed individuals gives: it is surjective and homogeneous, and the failure of ND at type $e$ that its non-injectivity brings adds nothing, ND failing already at type $t$.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: two-object chain — `full-two-object-chain`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain`, `full-two-object-chain-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [Σ true atom] — `full-two-object-chain-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `necessary-barcan-r-implies-barcan-r`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain`, `full-two-object-chain-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [infinitely many fixed individuals] — `full-two-object-chain-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain-individuals-fixed-infinite`, `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [infinitely many fixed individuals; ZF + socks] — `full-two-object-chain-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain-individuals-fixed-infinite-metatheory-socks`, `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [infinitely many fixed individuals; Σ true atom] — `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain-individuals-fixed-infinite`, `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object chain [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-no-pure-contingency-r`, `no-pure-contingency-r-implies-pure-b-r`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-pure-b-r`.

Model witness ids: `full-two-object-chain-individuals-fixed-infinite-metatheory-socks`, `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object retract — `full-two-object-retract`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract`, `full-two-object-retract-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [Σ true atom] — `full-two-object-retract-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-nd-imply-necessary-nd`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract`, `full-two-object-retract-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [infinitely many fixed individuals] — `full-two-object-retract-individuals-fixed-infinite`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract-individuals-fixed-infinite`, `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [infinitely many fixed individuals; ZF + socks] — `full-two-object-retract-individuals-fixed-infinite-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract-individuals-fixed-infinite-metatheory-socks`, `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [infinitely many fixed individuals; Σ true atom] — `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-nd-imply-necessary-nd`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract-individuals-fixed-infinite`, `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Full action model: two-object retract [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-possible-infinity-t`, `fregean-axiom-implies-distinctness-preserving-collapse`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-nd-imply-necessary-nd`, `necessary-distinctness-necessary-r-implies-necessary-barcan-r`, `necessary-atomicity-and-necessary-bf-imply-necessary-strong-leibniz`, `necessary-strong-leibniz-r-implies-necessary-strong-leibniz-t`, `necessary-strong-leibniz-t-implies-strong-leibniz-t`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `full-two-object-retract-individuals-fixed-infinite-metatheory-socks`, `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Henkin model: base without a choice function — `henkin-without-relational-choice`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-contingency-signature-r`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `extensionality-r-implies-rigid-comprehension-r`, `maximalist-distinctness-incompatible-with-rigid-comprehension`.

Model witness ids: `henkin-without-relational-choice`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 46, p. 32.

Record: `topics/classicism/models/henkin-without-relational-choice.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) — `symmetric-qualitative-contrast`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `actuality-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `symmetric-qualitative-contrast`, `symmetric-qualitative-contrast-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [Σ true atom] — `symmetric-qualitative-contrast-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-actuality-imply-necessary-actuality`, `c5-and-necessary-actuality-imply-atomicity`, `actuality-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`.

Model witness ids: `symmetric-qualitative-contrast`, `symmetric-qualitative-contrast-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [one individual] — `symmetric-qualitative-contrast-individuals-singleton`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `nd-and-bf-imply-necessary-nd`, `plenitude-r-implies-actuality`, `atomicity-r-implies-atomicity-t`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `necessary-countable-boolean-completeness-r-implies-countable-boolean-completeness-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `full-boolean-valued-atom-and-atomless`, `symmetric-qualitative-contrast-individuals-singleton`, `symmetric-qualitative-contrast-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [one individual; Σ true atom] — `symmetric-qualitative-contrast-individuals-singleton-sigma-true-atom`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `functional-choice-r-implies-plenitude-r`, `plenitude-r-implies-distinctness-necessary-r`, `nd-and-bf-imply-necessary-nd`, `plenitude-r-implies-actuality`, `atomicity-r-implies-atomicity-t`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `no-contingency-signature-r-implies-no-pure-contingency-r`, `no-pure-contingency-and-plenitude-imply-necessary-plenitude`, `necessary-plenitude-r-implies-atomicity-r`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `necessary-countable-boolean-completeness-r-implies-countable-boolean-completeness-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `full-boolean-valued-atom-and-atomless`, `symmetric-qualitative-contrast-individuals-singleton`, `symmetric-qualitative-contrast-individuals-singleton-sigma-true-atom`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Everything that implies these fails with them. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Central questions

Answering a central question settles many other open questions. A question is S ⊢ c, whether S entails c, for S at most two principle classes (True, with none) and c a class or False, asked only where no smaller premise set already proves or excludes c; S ⊢ False asks whether S is inconsistent. "No" denies the entailment, not the conditional. A question is settled alike by a proof, by an exclusion (S ∧ c ⇒ False) or by a recorded model that holds S and fails c. Each row scores an open question by the number of *other* open questions that stop being open once the answer joins the proved records. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. A model check (model: principle) scores deciding an unknown verdict inside a recorded model, which settles questions exactly as a proof does. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins classicism`.

### Under no extra assumptions

86 classes and 142 fitting models; 32688 open questions. 82% of questions with up to two premises settled (155319 of 188007).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | (Converse Witnessed Possibility ∧ Possibly Witnessed Possibility) or (Converse Witnessed Possibility ∧ Witnessed Possibility) or Logical Necessity or (Modal Freedom (signature Σ) ∧ Possibly Witnessed Possibility) or (Modal Freedom (signature Σ) ∧ Witnessed Possibility) ⊢ Actual Profile or □Actuality | 488 | 163 |
| 2 | BF (relational types) ∧ Maximalism (signature Σ) ⊢ ⊥ | 208 | 275 |
| 3 | Maximalism (signature Σ) ∧ Weakly Rigid Power ⊢ ⊥ | 120 | 422 |
| 4 | BF (type t) ∧ Maximalism (signature Σ) ⊢ ⊥ | 323 | 129 |
| 5 | Maximalism (signature Σ) ∧ Modalized Relational Choice ⊢ ⊥ | 132 | 294 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 4720 | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze | 24 | 22 | `strong-possibility-signature-r-implies-strong-possibility-r` |
| 6101 | Boolean Completeness ∧ Relational Choice ⊢ Transversal Choice ★ bronze | 15 | 29 | `relational-choice-and-boolean-completeness-imply-transversal-choice` |
| 10152 | □Strong Leibniz Biconditionals ∧ Rigid Comprehension ⊢ □BF (relational types) ★ bronze | 7 | 91 | `necessary-strong-leibniz-and-rigid-comprehension-imply-necessary-bf-relational` |
| 21607 | Rigid Power ∧ Tame Rigidity ⊢ Weakly Rigid Power ★ bronze | 3 | 3 | `tame-rigidity-and-rigid-power-imply-weakly-rigid-power` |
| 21844 | Relational Choice ⊢ Transversal Choice ★ bronze | 483 | 1 | `relational-choice-r-implies-transversal-choice-r` |
| 22363 | □Rigid Rigidity ⊢ Rigid Power ★ bronze | 189 | 1 | `rigid-rigidity-implies-rigid-power` |
| 25198 | Possible Infinity (type t) ⊢ Axiom of Infinity (type t) ★ bronze | 120 | 0 | `possible-infinity-t-implies-axiom-of-infinity-t` |
| — | BF ∧ Boolean Completeness ∧ □Atomicity ⊢ Rigid Comprehension ★ bronze  [refuted] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |
| — | Possible Infinity (type e) ⊢ Axiom of Infinity (type e) ★ bronze  [refuted] | — | — | `possible-infinity-e-implies-axiom-of-infinity-e` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Independence (signature Σ) ⊬ Strong Actuality | 0 | 1777 |
| 2 | Witnessed Possibility ⊬ Strong Actuality | 0 | 1710 |
| 3 | Independence (signature Σ) ∧ Necessity of Arithmetic ⊬ □Rigid Comprehension | 0 | 1651 |
| 4 | Maximalism (pure) ⊬ Distinctness-preserving collapse | 0 | 1619 |
| 5 | Necessity of Arithmetic ∧ Witnessed Possibility ⊬ □Rigid Comprehension | 0 | 1581 |

### Under C5

41 classes and 38 fitting models; 2491 open questions. 70% of questions with up to two premises settled (6097 of 8588).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | (□Relational Choice ∧ □Transversal) or □Transversal Choice ⊢ Intensional Choice or Modal Well-Ordering or Modalized Relational Choice or □Intensional Choice or □Modalized Relational Choice | 94 | 49 |
| 2 | (□Intensional Choice ∧ □Relational Choice) or □Modalized Relational Choice ⊢ Transversal Choice or Transversal | 55 | 55 |
| 3 | □Transversal Choice ∧ Necessity of Arithmetic ⊢ Intensional Choice or Modal Well-Ordering or Modalized Relational Choice or □Intensional Choice or □Modalized Relational Choice | 44 | 69 |
| 4 | Independence (signature Σ) ∧ □Functional Choice ⊢ ⊥ | 73 | 39 |
| 5 | □Modalized Relational Choice ∧ Necessity of Arithmetic ⊢ Transversal Choice or Transversal | 35 | 81 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 512 | Relational Choice ⊢ Transversal Choice ★ bronze | 161 | 6 | `relational-choice-r-implies-transversal-choice-r` |
| — | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze  [refuted] | — | — | `strong-possibility-signature-r-implies-strong-possibility-r` |
| — | Actual Profile ∧ Relational Choice ⊢ Transversal Choice ★ bronze  [proved] | — | — | `relational-choice-and-boolean-completeness-imply-transversal-choice` |
| — | Atomicity ⊢ Actual Profile ★ bronze  [proved] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Relational Choice ⊬ Modal Well-Ordering | 0 | 773 |
| 2 | Independence (signature Σ) ⊬ ⊥ | 0 | 755 |
| 3 | ⊤ ⊬ □Transversal | 0 | 560 |
| 4 | Independence (signature Σ) ⊬ □Functional Choice | 1 | 539 |
| 5 | Independence (signature Σ) ⊬ Distinctness-preserving collapse | 1 | 515 |

### Under C5 + Atomicity

22 classes and 31 fitting models; 116 open questions. 70% of questions with up to two premises settled (279 of 395).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | Distinctness-preserving collapse ∧ Independence (signature Σ) ⊢ ⊥ | 10 | 12 |
| 2 | Independence (signature Σ) ∧ No Contingency (signature Σ) ⊢ Infinity Schema (type t) | 11 | 8 |
| 3 | Independence (signature Σ) ∧ Intensional Choice ⊢ Infinity Schema (type t) | 12 | 5 |
| 4 | Independence (signature Σ) ∧ Modal Freedom (signature Σ) ⊢ Infinity Schema (type t) | 12 | 5 |
| 5 | Independence (signature Σ) ∧ No Contingency (signature Σ) ⊢ Axiom of Infinity (type t) | 12 | 5 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| — | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze  [refuted] | — | — | `strong-possibility-signature-r-implies-strong-possibility-r` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Independence (signature Σ) ⊬ ⊥ | 0 | 79 |
| 2 | Independence (signature Σ) ⊬ Distinctness-preserving collapse | 1 | 51 |
| 3 | Independence (signature Σ) ∧ Intensional Choice ⊬ ⊥ | 1 | 39 |
| 4 | Independence (signature Σ) ∧ Modal Freedom (signature Σ) ⊬ ⊥ | 1 | 39 |
| 5 | Independence (signature Σ) ∧ Infinity Schema (type e) ⊬ ⊥ | 1 | 32 |

### Under Extensionalism

19 classes and 3 fitting models; 14 open questions. 77% of questions with up to two premises settled (47 of 61).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | Axiom of Infinity (type e) ∧ Independence (signature Σ) ⊢ ⊥ | 4 | 2 |
| 2 | Independence (signature Σ) ∧ Infinity Schema (type e) ⊢ ⊥ | 8 | 1 |
| 3 | Functional Choice ∧ Independence (signature Σ) ⊢ ⊥ | 5 | 1 |
| 4 | Independence (signature Σ) ⊢ Axiom of Infinity (type e) | 4 | 1 |
| 5 | Functional Choice ∧ Independence (signature Σ) ⊢ Axiom of Infinity (type e) | 1 | 3 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| — | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze  [refuted] | — | — | `strong-possibility-signature-r-implies-strong-possibility-r` |
| — | Possible Infinity (type t) ⊢ Axiom of Infinity (type t) ★ bronze  [proved] | — | — | `possible-infinity-t-implies-axiom-of-infinity-t` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Independence (signature Σ) ⊬ ⊥ | 0 | 11 |
| 2 | Independence (signature Σ) ∧ Infinity Schema (type e) ⊬ ⊥ | 1 | 8 |
| 3 | Functional Choice ∧ Independence (signature Σ) ⊬ ⊥ | 1 | 5 |
| 4 | Axiom of Infinity (type e) ∧ Independence (signature Σ) ⊢ Functional Choice | 0 | 5 |
| 5 | Functional Choice ∧ Independence (signature Σ) ⊢ Infinity Schema (type e) | 0 | 5 |

### Under Pure Maximalist Classicism

97 classes and 3 fitting models; 8602 open questions. 20% of questions with up to two premises settled (2272 of 10874).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | (Actual Profile ∧ BF) or (BF ∧ Strong Actuality) ⊢ ⊥ | 89 | 61 |
| 2 | BF ∧ Strong Possibility (signature Σ) ⊢ ⊥ | 57 | 76 |
| 3 | BF ∧ Modalized Relational Choice ⊢ ⊥ | 62 | 62 |
| 4 | coalesced-single-individual-root: Maximalism (signature Σ) | 68 | 56 |
| 5 | BF ∧ Maximalism (signature Σ) ⊢ Distinctness-preserving collapse | 65 | 56 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 1657 | Relational Choice ⊢ Transversal Choice ★ bronze | 97 | 7 | `relational-choice-r-implies-transversal-choice-r` |
| 2728 | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze | 24 | 6 | `strong-possibility-signature-r-implies-strong-possibility-r` |
| 8093 | Rigid Power ∧ Tame Rigidity ⊢ Weakly Rigid Power ★ bronze | 0 | 7 | `tame-rigidity-and-rigid-power-imply-weakly-rigid-power` |
| — | Rigid Rigidity ⊢ Rigid Power ★ bronze  [refuted] | — | — | `rigid-rigidity-implies-rigid-power` |
| — | BF ∧ Boolean Completeness ∧ □Atomicity ⊢ Rigid Comprehension ★ bronze  [incompatible] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |
| — | Boolean Completeness ∧ Relational Choice ⊢ Transversal Choice ★ bronze  [incompatible] | — | — | `relational-choice-and-boolean-completeness-imply-transversal-choice` |
| — | □Strong Leibniz Biconditionals ∧ Rigid Comprehension ⊢ □BF (relational types) ★ bronze  [incompatible] | — | — | `necessary-strong-leibniz-and-rigid-comprehension-imply-necessary-bf-relational` |
| — | ⊤ ⊢ Axiom of Infinity (type e) ★ bronze  [refuted] | — | — | `possible-infinity-e-implies-axiom-of-infinity-e` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | ⊤ ⊬ Strong Actuality | 0 | 2490 |
| 2 | ⊤ ⊬ Distinctness-preserving collapse | 0 | 2362 |
| 3 | ⊤ ⊬ Actual Profile | 1 | 2210 |
| 4 | BF (type t) ⊬ ⊥ | 0 | 2082 |
| 5 | Intensional Choice ⊬ ⊥ | 0 | 1962 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### C5

Assuming `necessary-distinctness-necessary-r`, these remain open:

- □Transversal (`necessary-transversal-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Transversal (`transversal-r`)

### C5 + Atomicity

Assuming `necessary-distinctness-necessary-r`, `atomicity-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Pure Maximalist Classicism

Assuming `distinctness-schema-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Maximalism (signature Σ) (`distinctness-signature-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Strong Actuality (`strong-actuality`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Vicinity (`vicinity`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Well-Ordering (`well-ordering-r`)
- Witnessed Possibility (`witnessed-possibility-r`)
- Zorn's Lemma (`zorn-r`)

### BF + Weak Rigid Comprehension + Atomicity + Relational Choice

Assuming `barcan-r`, `weak-rigid-comprehension-r`, `atomicity-r`, `relational-choice-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### Well-Ordering + Weak Rigid Comprehension + BF

Assuming `well-ordering-r`, `weak-rigid-comprehension-r`, `barcan-r`, these remain open:

- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Vicinity (`necessary-vicinity`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### Strong Leibniz Biconditionals + □Rigid Comprehension + Rigid Power

Assuming `strong-leibniz-r`, `necessary-rigid-comprehension-r`, `rigid-power-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)

### Strong Leibniz Biconditionals (type t) + □Rigid Comprehension + Rigid Power

Assuming `strong-leibniz-t`, `necessary-rigid-comprehension-r`, `rigid-power-r`, these remain open:

- Atomicity (`atomicity-r`)
- BF (relational types) (`barcan-relational`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)

### Actuality + BF

Assuming `actuality`, `barcan-r`, these remain open:

- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### Actuality + BF (type t)

Assuming `actuality`, `barcan-t`, these remain open:

- BF (relational types) (`barcan-relational`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### Boolean Completeness + Actuality

Assuming `boolean-completeness-r`, `actuality`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)

### □BF + Actuality

Assuming `necessary-barcan-r`, `actuality`, these remain open:

- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □ND + Actuality

Assuming `necessary-distinctness-necessary-r`, `actuality`, these remain open:

- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Transversal (`necessary-transversal-r`)

### No Pure Contingency + Actuality

Assuming `no-pure-contingency-r`, `actuality`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- Strong Actuality (`strong-actuality`)

### Atomicity + BF

Assuming `atomicity-r`, `barcan-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### Atomicity + BF (relational types)

Assuming `atomicity-r`, `barcan-relational`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)

### No Pure Contingency + Atomicity

Assuming `no-pure-contingency-r`, `atomicity-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Rigid Power (`rigid-power-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Atomicity (type t) + BF

Assuming `atomicity-t`, `barcan-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### Atomicity (type t) + BF (type t)

Assuming `atomicity-t`, `barcan-t`, these remain open:

- Atomicity (`atomicity-r`)
- BF (relational types) (`barcan-relational`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)

### □ND + Atomicity (type t)

Assuming `necessary-distinctness-necessary-r`, `atomicity-t`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Atomicity (type t)

Assuming `no-pure-contingency-r`, `atomicity-t`, these remain open:

- Atomicity (`atomicity-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Rigid Power (`rigid-power-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Atomicity (type t) + Weakly Inextensible Comprehension

Assuming `atomicity-t`, `weakly-inextensible-comprehension-r`, these remain open:

- Atomicity (`atomicity-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □Persistent Comprehension (`necessary-persistent-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)

### ND + BF

Assuming `distinctness-necessary-r`, `barcan-r`, these remain open:

- □Transversal (`necessary-transversal-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Transversal (`transversal-r`)

### Gallin Extensional Comprehension + BF

Assuming `gallin-extensional-comprehension-r`, `barcan-r`, these remain open:

- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Transversal (`necessary-transversal-r`)

### No Pure Contingency + BF

Assuming `no-pure-contingency-r`, `barcan-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Possible Infinity (type e) + BF

Assuming `possible-infinity-e`, `barcan-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### Rigid Comprehension + BF

Assuming `rigid-comprehension-r`, `barcan-r`, these remain open:

- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)

### Tame Rigidity + BF

Assuming `tame-rigidity-r`, `barcan-r`, these remain open:

- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### BF + Weakly Rigid Power

Assuming `barcan-r`, `weakly-rigid-power-r`, these remain open:

- □Rigid Power (`necessary-rigid-power-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + BF (relational types)

Assuming `no-pure-contingency-r`, `barcan-relational`, these remain open:

- BF (`barcan-r`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (`necessary-barcan-r`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Tractarianism (`tractarianism-r`)

### Tame Rigidity + BF (relational types)

Assuming `tame-rigidity-r`, `barcan-relational`, these remain open:

- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + BF (type t)

Assuming `no-pure-contingency-r`, `barcan-t`, these remain open:

- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Tractarianism (`tractarianism-r`)

### Possible Infinity (type t) + BF (type t)

Assuming `possible-infinity-t`, `barcan-t`, these remain open:

- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- Functionality (`functionality-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Tractarianism (`tractarianism-r`)

### □ND + Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `boolean-completeness-r`, these remain open:

- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Transversal (`necessary-transversal-r`)

### No Pure Contingency + Boolean Completeness

Assuming `no-pure-contingency-r`, `boolean-completeness-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)

### No Pure Contingency + Boolean Completeness (type t)

Assuming `no-pure-contingency-r`, `boolean-completeness-t`, these remain open:

- Boolean Completeness (`boolean-completeness-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### No Pure Contingency + Countable Boolean Completeness

Assuming `no-pure-contingency-r`, `countable-boolean-completeness-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + ND

Assuming `no-pure-contingency-r`, `distinctness-necessary-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### ND + Strong Actuality

Assuming `distinctness-necessary-r`, `strong-actuality`, these remain open:

- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Plenitude (`plenitude-r`)
- Rigid Power (`rigid-power-r`)

### Weak Rigid Comprehension + ND

Assuming `weak-rigid-comprehension-r`, `distinctness-necessary-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### No Pure Contingency + ND (type t)

Assuming `no-pure-contingency-r`, `distinctness-necessary-t`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Maximalism (pure) + Separated Structure

Assuming `distinctness-schema-r`, `separated-structure-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Relational Choice (`relational-choice-r`)
- Strong Actuality (`strong-actuality`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Vicinity (`vicinity`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### No Pure Contingency + Functional Choice

Assuming `no-pure-contingency-r`, `functional-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Functionality

Assuming `no-pure-contingency-r`, `functionality-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Gallin Extensional Comprehension

Assuming `no-pure-contingency-r`, `gallin-extensional-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Inextensible Comprehension

Assuming `no-pure-contingency-r`, `inextensible-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □Relational Choice + Intensional Choice

Assuming `necessary-relational-choice-r`, `intensional-choice-r`, these remain open:

- Modal Well-Ordering (`modal-well-ordering-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### □Well-Ordering + Intensional Choice

Assuming `necessary-well-ordering-r`, `intensional-choice-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + Intensional Choice

Assuming `no-pure-contingency-r`, `intensional-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal (`transversal-r`)

### No Pure Contingency + B

Assuming `no-pure-contingency-r`, `modal-b`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### No Pure Contingency + 5

Assuming `no-pure-contingency-r`, `modal-five`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### 5 + Strong Leibniz Biconditionals (type t)

Assuming `modal-five`, `strong-leibniz-t`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Modalized Relational Choice

Assuming `no-pure-contingency-r`, `modalized-relational-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### □Actuality + □BF

Assuming `necessary-actuality`, `necessary-barcan-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □Actuality + □BF (type t)

Assuming `necessary-actuality`, `necessary-barcan-t`, these remain open:

- BF (relational types) (`barcan-relational`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □Boolean Completeness + □Actuality

Assuming `necessary-boolean-completeness-r`, `necessary-actuality`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)

### □ND + □Actuality

Assuming `necessary-distinctness-necessary-r`, `necessary-actuality`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □Atomicity + □BF

Assuming `necessary-atomicity-r`, `necessary-barcan-r`, these remain open:

- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### □Atomicity + □BF (relational types)

Assuming `necessary-atomicity-r`, `necessary-barcan-relational`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)

### □Atomicity + □BF (type t)

Assuming `necessary-atomicity-r`, `necessary-barcan-t`, these remain open:

- BF (relational types) (`barcan-relational`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)

### □Atomicity (type t) + □BF

Assuming `necessary-atomicity-t`, `necessary-barcan-r`, these remain open:

- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### □Atomicity (type t) + □BF (type t)

Assuming `necessary-atomicity-t`, `necessary-barcan-t`, these remain open:

- Atomicity (`atomicity-r`)
- BF (relational types) (`barcan-relational`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)

### □Atomicity (type t) + □Weakly Inextensible Comprehension

Assuming `necessary-atomicity-t`, `necessary-weakly-inextensible-comprehension-r`, these remain open:

- Atomicity (`atomicity-r`)
- □Atomicity (`necessary-atomicity-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)

### □Strong Leibniz Biconditionals (type t) + □BF

Assuming `necessary-strong-leibniz-t`, `necessary-barcan-r`, these remain open:

- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### □BF + Rigid Power

Assuming `necessary-barcan-r`, `rigid-power-r`, these remain open:

- □Rigid Power (`necessary-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □ND + □Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `necessary-boolean-completeness-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + □Persistent Comprehension

Assuming `necessary-distinctness-necessary-r`, `necessary-persistent-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + □Rigid Comprehension

Assuming `necessary-distinctness-necessary-r`, `necessary-rigid-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + □Strong Actuality

Assuming `necessary-distinctness-necessary-r`, `necessary-strong-actuality`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + Persistent Comprehension

Assuming `necessary-distinctness-necessary-r`, `persistent-comprehension-r`, these remain open:

- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Transversal (`necessary-transversal-r`)

### □Relational Choice + □Intensional Choice

Assuming `necessary-relational-choice-r`, `necessary-intensional-choice-r`, these remain open:

- Modal Well-Ordering (`modal-well-ordering-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### □Relational Choice + □Plenitude

Assuming `necessary-relational-choice-r`, `necessary-plenitude-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □Transversal + □Relational Choice

Assuming `necessary-transversal-r`, `necessary-relational-choice-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □Tame Rigidity + □Rigid Power

Assuming `necessary-tame-rigidity-r`, `necessary-rigid-power-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □Tame Rigidity + Rigid Power

Assuming `necessary-tame-rigidity-r`, `rigid-power-r`, these remain open:

- □Rigid Power (`necessary-rigid-power-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### Rigid Rigidity + □Tame Rigidity

Assuming `rigid-rigidity-r`, `necessary-tame-rigidity-r`, these remain open:

- □Rigid Power (`necessary-rigid-power-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Power (`rigid-power-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### □Vicinity + □Weakly Inextensible Comprehension

Assuming `necessary-vicinity`, `necessary-weakly-inextensible-comprehension-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + Persistent Comprehension

Assuming `no-pure-contingency-r`, `persistent-comprehension-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- Strong Actuality (`strong-actuality`)

### No Pure Contingency + Plenitude

Assuming `no-pure-contingency-r`, `plenitude-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Possible Infinity (type e) + No Pure Contingency

Assuming `possible-infinity-e`, `no-pure-contingency-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Possible Infinity (type t) + No Pure Contingency

Assuming `possible-infinity-t`, `no-pure-contingency-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Relational Choice

Assuming `no-pure-contingency-r`, `relational-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### No Pure Contingency + Rigid Comprehension

Assuming `no-pure-contingency-r`, `rigid-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- Strong Actuality (`strong-actuality`)

### No Pure Contingency + Rigid Power

Assuming `no-pure-contingency-r`, `rigid-power-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### No Pure Contingency + Strong Actuality

Assuming `no-pure-contingency-r`, `strong-actuality`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)

### No Pure Contingency + Strong Leibniz Biconditionals

Assuming `no-pure-contingency-r`, `strong-leibniz-r`, these remain open:

- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### No Pure Contingency + Strong Leibniz Biconditionals (type t)

Assuming `no-pure-contingency-r`, `strong-leibniz-t`, these remain open:

- Atomicity (`atomicity-r`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### No Pure Contingency + Tame Rigidity

Assuming `no-pure-contingency-r`, `tame-rigidity-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Tractarianism

Assuming `no-pure-contingency-r`, `tractarianism-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Transversal Choice

Assuming `no-pure-contingency-r`, `transversal-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Tame Rigidity (`tame-rigidity-r`)

### No Pure Contingency + Transversal

Assuming `no-pure-contingency-r`, `transversal-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Vicinity

Assuming `no-pure-contingency-r`, `vicinity`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### No Pure Contingency + Weak Rigid Comprehension

Assuming `no-pure-contingency-r`, `weak-rigid-comprehension-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- Strong Actuality (`strong-actuality`)

### No Pure Contingency + Weakly Inextensible Comprehension

Assuming `no-pure-contingency-r`, `weakly-inextensible-comprehension-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)

### No Pure Contingency + Weakly Rigid Power

Assuming `no-pure-contingency-r`, `weakly-rigid-power-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Well-Ordering

Assuming `no-pure-contingency-r`, `well-ordering-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- Tame Rigidity (`tame-rigidity-r`)

### Witnessed Possibility + No Pure Contingency

Assuming `witnessed-possibility-r`, `no-pure-contingency-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (`barcan-r`)
- BF (relational types) (`barcan-relational`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type t) (`infinity-t`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Atomicity (type t) (`necessary-atomicity-t`)
- □BF (`necessary-barcan-r`)
- □BF (relational types) (`necessary-barcan-relational`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Persistent Comprehension (`necessary-persistent-comprehension-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Strong Actuality (`necessary-strong-actuality`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- □Weak Rigid Comprehension (`necessary-weak-rigid-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Strong Actuality (`strong-actuality`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)
- Tame Rigidity (`tame-rigidity-r`)
- Tractarianism (`tractarianism-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Vicinity (`vicinity`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Relational Choice + Plenitude

Assuming `relational-choice-r`, `plenitude-r`, these remain open:

- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Rigid Power (`rigid-power-r`)
- Tame Rigidity (`tame-rigidity-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)

### Relational Choice + Weak Rigid Comprehension

Assuming `relational-choice-r`, `weak-rigid-comprehension-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Rigid Power (`rigid-power-r`)

### Tame Rigidity + Weak Rigid Comprehension

Assuming `tame-rigidity-r`, `weak-rigid-comprehension-r`, these remain open:

- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Tame Rigidity (`necessary-tame-rigidity-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Coalesced sum: root over all finite individual domains — `coalesced-all-finite-individual-domains`

Fully determined; nothing unknown.

### Coalesced sum: root individuals indexed by infinitely many individual constants — `coalesced-constant-indexed-root`

Fully determined; nothing unknown.

### Coalesced sum: maximalist root — `coalesced-maximalist-root`

Fully determined; nothing unknown.

### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

- Maximalism (signature Σ) (`distinctness-signature-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Possibility+ (signature Σ) (`possibility-plus-signature-r`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

Fully determined; nothing unknown.

### Finite-support action model: dyadic roundings of N [Σ true atom] — `finite-support-dyadic-roundings-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: dyadic roundings of N [one individual] — `finite-support-dyadic-roundings-individuals-singleton`

Fully determined; nothing unknown.

### Finite-support action model: dyadic roundings of N [one individual; Σ true atom] — `finite-support-dyadic-roundings-individuals-singleton-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: identity-or-collapse monotone surjections [Σ true atom] — `finite-support-identity-or-collapse-surjections-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: identity-or-collapse monotone surjections [one individual] — `finite-support-identity-or-collapse-surjections-individuals-singleton`

- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: identity-or-collapse monotone surjections [one individual; Σ true atom] — `finite-support-identity-or-collapse-surjections-individuals-singleton-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

Fully determined; nothing unknown.

### Finite-support action model: identity-or-collapse monotone maps [Σ true atom] — `finite-support-identity-or-collapse-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: identity-or-collapse monotone maps [one individual] — `finite-support-identity-or-collapse-individuals-singleton`

Fully determined; nothing unknown.

### Finite-support action model: identity-or-collapse monotone maps [one individual; Σ true atom] — `finite-support-identity-or-collapse-individuals-singleton-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

- Independence (signature Σ) (`independence-signature-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- B for sentences of Σ (`signature-b-r`)

### Finite-support action model: monotone maps of N [Σ top] — `finite-support-monotone-maps-sigma-top`

Fully determined; nothing unknown.

### Finite-support action model: monotone maps of N [one individual] — `finite-support-monotone-maps-individuals-singleton`

- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- B for sentences of Σ (`signature-b-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### Finite-support action model: monotone maps of N [one individual; Σ top] — `finite-support-monotone-maps-individuals-singleton-sigma-top`

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: monotone surjections of N [one individual] — `finite-support-monotone-surjections-individuals-singleton`

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Rigid Power (`necessary-rigid-power-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- □Weakly Rigid Power (`necessary-weakly-rigid-power-r`)
- □Weakly Rigid Weak Rigidity (`necessary-weakly-rigid-weak-rigidity-r`)
- Rigid Power (`rigid-power-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Weakly Rigid Power (`weakly-rigid-power-r`)
- Weakly Rigid Weak Rigidity (`weakly-rigid-weak-rigidity-r`)

### Finite-support action model: pair-preserving injections and pair collapses of N — `finite-support-pair-injections-or-collapses`

Fully determined; nothing unknown.

### Finite-support action model: pair-preserving injections and pair collapses of N [one individual] — `finite-support-pair-injections-or-collapses-individuals-singleton`

Fully determined; nothing unknown.

### Finite-support action model: permutations of N — `finite-support-permutations`

Fully determined; nothing unknown.

### Finite-support action model: permutations of N [one individual] — `finite-support-permutations-individuals-singleton`

Fully determined; nothing unknown.

### Finite-support action model: N and N×2, sections and projection — `finite-support-sections-and-projection`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Functional Choice (`functional-choice-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Plenitude (`plenitude-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

Fully determined; nothing unknown.

### Finite-support action model: truncated shifts of N [Σ true atom] — `finite-support-truncated-shifts-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: truncated shifts of N [one individual] — `finite-support-truncated-shifts-individuals-singleton`

Fully determined; nothing unknown.

### Finite-support action model: truncated shifts of N [one individual; Σ true atom] — `finite-support-truncated-shifts-individuals-singleton-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: truncations of N — `finite-support-truncations`

Fully determined; nothing unknown.

### Finite-support action model: truncations of N [one individual] — `finite-support-truncations-individuals-singleton`

Fully determined; nothing unknown.

### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

- Modal Well-Ordering (`modal-well-ordering-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)

### Full Boolean-valued model: one atom and an atomless component — `full-boolean-valued-atom-and-atomless`

Fully determined; nothing unknown.

### Full action model: free monoid on countably many generators, glued constants, singleton individuals — `full-free-monoid-glued-constants-singleton`

Fully determined; nothing unknown.

### Full action model: free monoid on countably many generators, glued constants, thread individuals — `full-free-monoid-glued-constants`

Fully determined; nothing unknown.

### Full Henkin model: countably infinite individual domain — `full-henkin-infinite-base`

Fully determined; nothing unknown.

### Full Henkin model: singleton individual domain — `full-henkin-singleton-base`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid [Σ true atom] — `full-idempotent-monoid-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals] — `full-idempotent-monoid-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; ZF + socks] — `full-idempotent-monoid-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; Σ true atom] — `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: idempotent two-arrow monoid [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-idempotent-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 — `full-infinite-s5`

Fully determined; nothing unknown.

### Full action model: infinite S5 [ZF + ¬AC_ω(ℝ)] — `full-infinite-s5-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: infinite S5 [ZF + socks] — `full-infinite-s5-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: infinite S5 [Σ true atom] — `full-infinite-s5-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-infinite-s5-sigma-true-atom-metatheory-no-countable-choice-reals`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [Σ true atom; ZF + socks] — `full-infinite-s5-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [infinitely many fixed individuals] — `full-infinite-s5-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: infinite S5 [infinitely many fixed individuals; ZF + ¬AC_ω(ℝ)] — `full-infinite-s5-individuals-fixed-infinite-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: infinite S5 [infinitely many fixed individuals; ZF + socks] — `full-infinite-s5-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: infinite S5 [infinitely many fixed individuals; Σ true atom] — `full-infinite-s5-individuals-fixed-infinite-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [infinitely many fixed individuals; Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-infinite-s5-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: infinite S5 [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-infinite-s5-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: two-element group — `full-involution-group`

Fully determined; nothing unknown.

### Full action model: two-element group [Σ true atom] — `full-involution-group-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: two-element group [infinitely many fixed individuals] — `full-involution-group-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-element group [infinitely many fixed individuals; ZF + socks] — `full-involution-group-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: two-element group [infinitely many fixed individuals; Σ true atom] — `full-involution-group-individuals-fixed-infinite-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: two-element group [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-involution-group-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: permutations of an infinite set — `full-permutation-group-infinite-set`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [ZF + ¬AC_ω(ℝ)] — `full-permutation-group-infinite-set-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [Σ true atom] — `full-permutation-group-infinite-set-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-permutation-group-infinite-set-sigma-true-atom-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals] — `full-permutation-group-infinite-set-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; ZF + ¬AC_ω(ℝ)] — `full-permutation-group-infinite-set-individuals-fixed-infinite-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; ZF + socks] — `full-permutation-group-infinite-set-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; Σ true atom] — `full-permutation-group-infinite-set-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-permutation-group-infinite-set-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-permutation-group-infinite-set-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set — `full-surjection-monoid`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set [ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set [ZF + socks] — `full-surjection-monoid-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set [Σ true atom] — `full-surjection-monoid-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: surjections of an infinite set [Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-sigma-true-atom-metatheory-no-countable-choice-reals`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: surjections of an infinite set [Σ true atom; ZF + socks] — `full-surjection-monoid-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: surjections of an infinite set [infinitely many fixed individuals] — `full-surjection-monoid-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set [infinitely many fixed individuals; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-individuals-fixed-infinite-metatheory-no-countable-choice-reals`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set [infinitely many fixed individuals; ZF + socks] — `full-surjection-monoid-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + ¬AC_ω(ℝ)] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-no-countable-choice-reals`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: surjections of an infinite set [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-surjection-monoid-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Full action model: two-object chain, one individual becoming two — `full-two-object-chain-new-individual`

Fully determined; nothing unknown.

### Full action model: two-object chain — `full-two-object-chain`

Fully determined; nothing unknown.

### Full action model: two-object chain [Σ true atom] — `full-two-object-chain-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object chain [infinitely many fixed individuals] — `full-two-object-chain-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-object chain [infinitely many fixed individuals; ZF + socks] — `full-two-object-chain-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: two-object chain [infinitely many fixed individuals; Σ true atom] — `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object chain [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-chain-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions — `full-two-object-double-retraction`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [Σ true atom] — `full-two-object-double-retraction-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [infinitely many fixed individuals] — `full-two-object-double-retraction-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [infinitely many fixed individuals; ZF + socks] — `full-two-object-double-retraction-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [infinitely many fixed individuals; Σ true atom] — `full-two-object-double-retraction-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object retract with two retractions [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-double-retraction-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: two-object retract — `full-two-object-retract`

Fully determined; nothing unknown.

### Full action model: two-object retract [Σ true atom] — `full-two-object-retract-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object retract [infinitely many fixed individuals] — `full-two-object-retract-individuals-fixed-infinite`

Fully determined; nothing unknown.

### Full action model: two-object retract [infinitely many fixed individuals; ZF + socks] — `full-two-object-retract-individuals-fixed-infinite-metatheory-socks`

Fully determined; nothing unknown.

### Full action model: two-object retract [infinitely many fixed individuals; Σ true atom] — `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom`

Fully determined; nothing unknown.

### Full action model: two-object retract [infinitely many fixed individuals; Σ true atom; ZF + socks] — `full-two-object-retract-individuals-fixed-infinite-sigma-true-atom-metatheory-socks`

Fully determined; nothing unknown.

### Henkin model: base without a choice function — `henkin-without-relational-choice`

Fully determined; nothing unknown.

### Symmetric ideally-full model: all surjections of N (Base 1) — `symmetric-all-surjections`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### Symmetric ideally-full model: all surjections of N (Base 1) [one individual] — `symmetric-all-surjections-individuals-singleton`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) — `symmetric-collapse-pair`

Fully determined; nothing unknown.

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) [Σ true atom] — `symmetric-collapse-pair-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) [one individual] — `symmetric-collapse-pair-individuals-singleton`

- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) [one individual; Σ true atom] — `symmetric-collapse-pair-individuals-singleton-sigma-true-atom`

- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: automorphisms of infinitely many infinite classes — `symmetric-infinite-classes`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### Symmetric ideally-full model: automorphisms of infinitely many infinite classes [one individual] — `symmetric-infinite-classes-individuals-singleton`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: old and new individuals — `symmetric-old-new-individuals`

- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Intensional Choice (`intensional-choice-r`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Plenitude (`plenitude-r`)

### Symmetric ideally-full model: old and new individuals [one individual] — `symmetric-old-new-individuals-individuals-singleton`

- Functional Choice (`functional-choice-r`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) — `symmetric-qualitative-contrast`

- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Transversal (`necessary-transversal-r`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [Σ true atom] — `symmetric-qualitative-contrast-sigma-true-atom`

- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Transversal (`necessary-transversal-r`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [one individual] — `symmetric-qualitative-contrast-individuals-singleton`

- Functional Choice (`functional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) [one individual; Σ true atom] — `symmetric-qualitative-contrast-individuals-singleton-sigma-true-atom`

- Functional Choice (`functional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Boolean Completeness (type t) (`necessary-boolean-completeness-t`)
- □Countable Boolean Completeness (`necessary-countable-boolean-completeness-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: qualitative link structure (Base 3) — `symmetric-qualitative-links`

- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### Symmetric ideally-full model: qualitative link structure (Base 3) [Σ true atom] — `symmetric-qualitative-links-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- Rigid Rigidity (`rigid-rigidity-r`)

### Symmetric ideally-full model: qualitative link structure (Base 3) [one individual] — `symmetric-qualitative-links-individuals-singleton`

- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: qualitative link structure (Base 3) [one individual; Σ true atom] — `symmetric-qualitative-links-individuals-singleton-sigma-true-atom`

- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Rigidity (`necessary-rigid-rigidity-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Rigid Rigidity (`rigid-rigidity-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: arrows omitting or reserving a fixed individual — `symmetric-range-gap-without-actuality`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Symmetric ideally-full model: arrows omitting or reserving a fixed individual [one individual] — `symmetric-range-gap-without-actuality-individuals-singleton`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: arrows omitting a fixed individual — `symmetric-range-gap`

Fully determined; nothing unknown.

### Symmetric ideally-full model: arrows omitting a fixed individual [Σ true atom] — `symmetric-range-gap-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetric ideally-full model: arrows omitting a fixed individual [one individual] — `symmetric-range-gap-individuals-singleton`

- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: arrows omitting a fixed individual [one individual; Σ true atom] — `symmetric-range-gap-individuals-singleton-sigma-true-atom`

- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: two objects, the second unpinned — `symmetric-two-object-unpinned`

- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)

### Symmetric ideally-full model: two objects, the second unpinned [Σ true atom] — `symmetric-two-object-unpinned-sigma-true-atom`

- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)

### Symmetric ideally-full model: two objects, the second unpinned [one individual] — `symmetric-two-object-unpinned-individuals-singleton`

- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- B for sentences of Σ (`signature-b-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetric ideally-full model: two objects, the second unpinned [one individual; Σ true atom] — `symmetric-two-object-unpinned-individuals-singleton-sigma-true-atom`

- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Inextensible Comprehension (`necessary-inextensible-comprehension-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Well-Ordering (`necessary-well-ordering-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Well-Ordering (`well-ordering-r`)
- Zorn's Lemma (`zorn-r`)

### Symmetry-constrained full model: all maps on three individuals — `symmetry-constrained-full-all-maps`

Fully determined; nothing unknown.

### Symmetry-constrained full model: all maps on three individuals [Σ true atom] — `symmetry-constrained-full-all-maps-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetry-constrained full model: all maps on three individuals [one individual] — `symmetry-constrained-full-all-maps-individuals-singleton`

Fully determined; nothing unknown.

### Symmetry-constrained full model: all maps on three individuals [one individual; Σ true atom] — `symmetry-constrained-full-all-maps-individuals-singleton-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetry-constrained full model: permutations and collapses on three individuals — `symmetry-constrained-full-collapse`

Fully determined; nothing unknown.

### Symmetry-constrained full model: permutations and collapses on three individuals [Σ true atom] — `symmetry-constrained-full-collapse-sigma-true-atom`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetry-constrained full model: permutations and collapses on three individuals [one individual] — `symmetry-constrained-full-collapse-individuals-singleton`

- Intensional Choice (`intensional-choice-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)

### Symmetry-constrained full model: permutations and collapses on three individuals [one individual; Σ true atom] — `symmetry-constrained-full-collapse-individuals-singleton-sigma-true-atom`

- Intensional Choice (`intensional-choice-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Modal Well-Ordering (`modal-well-ordering-r`)
- Modalized Relational Choice (`modalized-relational-choice-r`)
- □Intensional Choice (`necessary-intensional-choice-r`)
- □Modalized Relational Choice (`necessary-modalized-relational-choice-r`)

### Action model: a fork with an ultralimit world — `ultralimit-fork`

Fully determined; nothing unknown.

## 5. Open single-premise pairs (580)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **5** (`modal-five`) ⇒ Necessity of Arithmetic, Rigid Power, Transversal, □Rigid Power, □Transversal, □Vicinity
- **Atomicity** (`atomicity-r`) ⇒ Necessity of Arithmetic, Rigid Power, Transversal, □Atomicity, □Atomicity (type t), □Rigid Power, □Transversal
- **Atomicity (type t)** (`atomicity-t`) ⇒ Atomicity, Necessity of Arithmetic, Rigid Power, Transversal, □Atomicity, □Atomicity (type t), □Rigid Power, □Transversal
- **Atomlessness** (`atomlessness`) ⇒ B for pure sentences, B for sentences of Σ, Converse Witnessed Possibility, Modal Freedom (signature Σ), Necessity of Arithmetic, No Pure Contingency, Tame Rigidity, □Tame Rigidity
- **B** (`modal-b`) ⇒ Necessity of Arithmetic, Rigid Power, Transversal, □Rigid Power, □Transversal, □Vicinity
- **B for pure sentences** (`pure-b-r`) ⇒ Necessity of Arithmetic
- **B for sentences of Σ** (`signature-b-r`) ⇒ Necessity of Arithmetic
- **BF** (`barcan-r`) ⇒ Necessity of Arithmetic
- **BF (relational types)** (`barcan-relational`) ⇒ Necessity of Arithmetic
- **BF (type t)** (`barcan-t`) ⇒ BF (relational types), Necessity of Arithmetic
- **Boolean Completeness** (`boolean-completeness-r`) ⇒ Inextensible Comprehension, □Countable Boolean Completeness
- **Boolean Completeness (type t)** (`boolean-completeness-t`) ⇒ Countable Boolean Completeness, Necessity of Arithmetic, Weakly Inextensible Comprehension, □Countable Boolean Completeness
- **Converse Witnessed Possibility** (`converse-witnessed-possibility-r`) ⇒ Modal Freedom (signature Σ)
- **Countable Boolean Completeness** (`countable-boolean-completeness-r`) ⇒ □Countable Boolean Completeness
- **Distinctness-preserving collapse** (`distinctness-preserving-collapse`) ⇒ Transversal
- **Functional Choice** (`functional-choice-r`) ⇒ Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Inextensible Comprehension, Intensional Choice, Modal Well-Ordering, Modalized Relational Choice, Necessity of Arithmetic, Rigid Comprehension, Rigid Power, Tame Rigidity, Weak Rigid Comprehension, Weakly Rigid Power, □Countable Boolean Completeness, □Intensional Choice, □Modalized Relational Choice, □Relational Choice, □Rigid Power, □Tame Rigidity, □Transversal, □Transversal Choice, □Vicinity, □Weakly Rigid Power, □Well-Ordering
- **Functionality** (`functionality-r`) ⇒ Necessity of Arithmetic
- **Gallin Extensional Comprehension** (`gallin-extensional-comprehension-r`) ⇒ Boolean Completeness (type t), Countable Boolean Completeness, Necessity of Arithmetic, Plenitude, Rigid Power, □Countable Boolean Completeness, □Rigid Power, □Transversal, □Vicinity
- **Independence (signature Σ)** (`independence-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Strong Actuality, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Witnessed Possibility, Zorn's Lemma
- **Infinity Schema (type e)** (`infinity-e`) ⇒ Axiom of Infinity (type e), Possible Infinity (type e)
- **Infinity Schema (type t)** (`infinity-t`) ⇒ Axiom of Infinity (type t), Possible Infinity (type t)
- **Intensional Choice** (`intensional-choice-r`) ⇒ Necessity of Arithmetic, Transversal, □Intensional Choice, □Transversal
- **Logical Necessity** (`logical-necessity-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type t), BF, BF (relational types), BF (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type t), Intensional Choice, Modal Well-Ordering, Modalized Relational Choice, Persistent Comprehension, Possible Infinity (type t), Relational Choice, Rigid Comprehension, Rigid Power, Rigid Rigidity, Strong Actuality, Strong Leibniz Biconditionals, Strong Leibniz Biconditionals (type t), Tame Rigidity, Tractarianism, Transversal, Transversal Choice, Vicinity, Weak Rigid Comprehension, Weakly Inextensible Comprehension, Weakly Rigid Power, Weakly Rigid Weak Rigidity, Well-Ordering, Zorn's Lemma, □Actuality, □Atomicity, □Atomicity (type t), □BF, □BF (relational types), □BF (type t), □Boolean Completeness, □Boolean Completeness (type t), □Countable Boolean Completeness, □Functionality, □Inextensible Comprehension, □Intensional Choice, □Modalized Relational Choice, □Persistent Comprehension, □Relational Choice, □Rigid Comprehension, □Rigid Power, □Rigid Rigidity, □Strong Actuality, □Strong Leibniz Biconditionals, □Strong Leibniz Biconditionals (type t), □Tame Rigidity, □Tractarianism, □Transversal, □Transversal Choice, □Vicinity, □Weak Rigid Comprehension, □Weakly Inextensible Comprehension, □Weakly Rigid Power, □Weakly Rigid Weak Rigidity, □Well-Ordering
- **Maximalism (pure)** (`distinctness-schema-r`) ⇒ Actual Profile, Actuality, Distinctness-preserving collapse, Independence (signature Σ), Inextensible Comprehension, Maximalism (signature Σ), Persistent Comprehension, Possibly Witnessed Possibility, Relational Choice, Separated Structure, Strong Actuality, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Witnessed Possibility, Zorn's Lemma
- **Maximalism (signature Σ)** (`distinctness-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type e), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Relational Choice, Strong Actuality, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Zorn's Lemma
- **Modal Well-Ordering** (`modal-well-ordering-r`) ⇒ Necessity of Arithmetic
- **Modalized Relational Choice** (`modalized-relational-choice-r`) ⇒ Modal Well-Ordering, Necessity of Arithmetic, Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma, □Intensional Choice, □Modalized Relational Choice, □Relational Choice, □Transversal, □Transversal Choice, □Well-Ordering
- **ND** (`distinctness-necessary-r`) ⇒ Necessity of Arithmetic, Rigid Power, Transversal, □Rigid Power, □Transversal, □Vicinity
- **ND (type t)** (`distinctness-necessary-t`) ⇒ Necessity of Arithmetic, Rigid Power, Transversal, □Rigid Power, □Transversal, □Vicinity
- **No Pure Contingency** (`no-pure-contingency-r`) ⇒ Modal Freedom (signature Σ)
- **Plenitude** (`plenitude-r`) ⇒ Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Inextensible Comprehension, Necessity of Arithmetic, Rigid Comprehension, Rigid Power, Tame Rigidity, Weak Rigid Comprehension, Weakly Rigid Power, □Countable Boolean Completeness, □Rigid Power, □Tame Rigidity, □Transversal, □Vicinity, □Weakly Rigid Power
- **Possibility+ (pure)** (`possibility-plus-r`) ⇒ Actual Profile, Actuality, Distinctness-preserving collapse, Independence (signature Σ), Inextensible Comprehension, Maximalism (signature Σ), Persistent Comprehension, Possibility+ (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Strong Actuality, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Witnessed Possibility, Zorn's Lemma
- **Possibility+ (signature Σ)** (`possibility-plus-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type e), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Relational Choice, Strong Actuality, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Zorn's Lemma
- **Possible Infinity (type t)** (`possible-infinity-t`) ⇒ Axiom of Infinity (type t), Infinity Schema (type t)
- **Possibly Witnessed Possibility** (`possibly-witnessed-possibility-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice, Strong Actuality, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Zorn's Lemma
- **Relational Choice** (`relational-choice-r`) ⇒ Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma
- **Rigid Comprehension** (`rigid-comprehension-r`) ⇒ □Countable Boolean Completeness, □Tame Rigidity, □Transversal, □Vicinity
- **Rigid Power** (`rigid-power-r`) ⇒ Necessity of Arithmetic, □Rigid Power
- **Rigid Rigidity** (`rigid-rigidity-r`) ⇒ Necessity of Arithmetic, Rigid Power, □Rigid Power
- **Separated Structure** (`separated-structure-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice, Strong Actuality, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Zorn's Lemma
- **Strong Leibniz Biconditionals** (`strong-leibniz-r`) ⇒ BF (relational types), BF (type t), Inextensible Comprehension, Necessity of Arithmetic, Rigid Power, □Atomicity, □Atomicity (type t), □BF (relational types), □BF (type t), □Inextensible Comprehension, □Rigid Power, □Strong Actuality, □Strong Leibniz Biconditionals, □Strong Leibniz Biconditionals (type t)
- **Strong Leibniz Biconditionals (type t)** (`strong-leibniz-t`) ⇒ Atomicity, BF (relational types), BF (type t), Inextensible Comprehension, Necessity of Arithmetic, Rigid Power, Strong Leibniz Biconditionals, □Atomicity, □Atomicity (type t), □BF (relational types), □BF (type t), □Inextensible Comprehension, □Rigid Power, □Strong Actuality, □Strong Leibniz Biconditionals, □Strong Leibniz Biconditionals (type t)
- **Strong Possibility (pure)** (`strong-possibility-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), BF, BF (relational types), BF (type t), Boolean Completeness (type t), Functionality, Independence (signature Σ), Inextensible Comprehension, Infinity Schema (type e), Intensional Choice, Maximalism (signature Σ), Modalized Relational Choice, Persistent Comprehension, Possibility+ (pure), Possibility+ (signature Σ), Possibly Witnessed Possibility, Relational Choice, Rigid Power, Separated Structure, Strong Actuality, Strong Possibility (signature Σ), Tame Rigidity, Tractarianism, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Weakly Rigid Power, Well-Ordering, Witnessed Possibility, Zorn's Lemma
- **Strong Possibility (signature Σ)** (`strong-possibility-signature-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), BF, BF (relational types), BF (type t), Boolean Completeness (type t), Functionality, Inextensible Comprehension, Infinity Schema (type e), Intensional Choice, Modalized Relational Choice, Persistent Comprehension, Possibility+ (pure), Possibility+ (signature Σ), Relational Choice, Rigid Power, Strong Actuality, Strong Possibility (pure), Tame Rigidity, Tractarianism, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Weakly Rigid Power, Well-Ordering, Zorn's Lemma
- **Tame Rigidity** (`tame-rigidity-r`) ⇒ Necessity of Arithmetic, □Tame Rigidity
- **Tractarianism** (`tractarianism-r`) ⇒ Necessity of Arithmetic
- **Vicinity** (`vicinity`) ⇒ Transversal
- **Weak Rigid Comprehension** (`weak-rigid-comprehension-r`) ⇒ Inextensible Comprehension, □Countable Boolean Completeness, □Transversal, □Vicinity
- **Weakly Rigid Power** (`weakly-rigid-power-r`) ⇒ Necessity of Arithmetic, □Rigid Power, □Tame Rigidity, □Weakly Rigid Power
- **Weakly Rigid Weak Rigidity** (`weakly-rigid-weak-rigidity-r`) ⇒ Necessity of Arithmetic, Rigid Power, Weakly Rigid Power, □Rigid Power, □Weakly Rigid Power
- **Witnessed Possibility** (`witnessed-possibility-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Independence (signature Σ), Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Strong Actuality, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Well-Ordering, Zorn's Lemma
- **□5** (`necessary-modal-five`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□Actuality** (`necessary-actuality`) ⇒ Necessity of Arithmetic
- **□Atomicity** (`necessary-atomicity-r`) ⇒ Necessity of Arithmetic, Rigid Power, Transversal, □Rigid Power, □Transversal
- **□Atomicity (type t)** (`necessary-atomicity-t`) ⇒ Atomicity, Necessity of Arithmetic, Rigid Power, Transversal, □Atomicity, □Rigid Power, □Transversal
- **□B** (`necessary-modal-b`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□BF** (`necessary-barcan-r`) ⇒ Necessity of Arithmetic
- **□BF (relational types)** (`necessary-barcan-relational`) ⇒ Necessity of Arithmetic
- **□BF (type t)** (`necessary-barcan-t`) ⇒ BF (relational types), Necessity of Arithmetic, □BF (relational types)
- **□Boolean Completeness** (`necessary-boolean-completeness-r`) ⇒ Inextensible Comprehension, □Inextensible Comprehension, □Weakly Inextensible Comprehension
- **□Boolean Completeness (type t)** (`necessary-boolean-completeness-t`) ⇒ Countable Boolean Completeness, Necessity of Arithmetic, Weakly Inextensible Comprehension, □Countable Boolean Completeness, □Weakly Inextensible Comprehension
- **□Functional Choice** (`necessary-functional-choice-r`) ⇒ Modal Freedom (signature Σ)
- **□Functionality** (`necessary-functionality-r`) ⇒ Necessity of Arithmetic
- **□Gallin Extensional Comprehension** (`necessary-gallin-extensional-comprehension-r`) ⇒ Modal Freedom (signature Σ)
- **□Inextensible Comprehension** (`necessary-inextensible-comprehension-r`) ⇒ Necessity of Arithmetic
- **□Intensional Choice** (`necessary-intensional-choice-r`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□Modalized Relational Choice** (`necessary-modalized-relational-choice-r`) ⇒ Modal Well-Ordering, Necessity of Arithmetic, Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma, □Transversal, □Transversal Choice, □Well-Ordering
- **□ND** (`necessary-distinctness-necessary-r`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□ND (type t)** (`necessary-distinctness-necessary-t`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□Persistent Comprehension** (`necessary-persistent-comprehension-r`) ⇒ Necessity of Arithmetic
- **□Plenitude** (`necessary-plenitude-r`) ⇒ Modal Freedom (signature Σ)
- **□Relational Choice** (`necessary-relational-choice-r`) ⇒ Necessity of Arithmetic, Transversal, Transversal Choice, Well-Ordering, Zorn's Lemma, □Transversal, □Transversal Choice, □Well-Ordering
- **□Rigid Power** (`necessary-rigid-power-r`) ⇒ Necessity of Arithmetic
- **□Rigid Rigidity** (`necessary-rigid-rigidity-r`) ⇒ Necessity of Arithmetic, Rigid Power, □Rigid Power
- **□Strong Actuality** (`necessary-strong-actuality`) ⇒ Necessity of Arithmetic
- **□Strong Leibniz Biconditionals** (`necessary-strong-leibniz-r`) ⇒ BF (relational types), BF (type t), Inextensible Comprehension, Necessity of Arithmetic, Rigid Power, □BF (relational types), □BF (type t), □Inextensible Comprehension, □Rigid Power
- **□Strong Leibniz Biconditionals (type t)** (`necessary-strong-leibniz-t`) ⇒ Atomicity, BF (relational types), BF (type t), Inextensible Comprehension, Necessity of Arithmetic, Rigid Power, Strong Leibniz Biconditionals, □Atomicity, □BF (relational types), □BF (type t), □Inextensible Comprehension, □Rigid Power, □Strong Leibniz Biconditionals
- **□Tame Rigidity** (`necessary-tame-rigidity-r`) ⇒ Necessity of Arithmetic
- **□Tractarianism** (`necessary-tractarianism-r`) ⇒ Necessity of Arithmetic
- **□Transversal** (`necessary-transversal-r`) ⇒ Necessity of Arithmetic
- **□Transversal Choice** (`necessary-transversal-choice-r`) ⇒ Necessity of Arithmetic
- **□Vicinity** (`necessary-vicinity`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□Weak Rigid Comprehension** (`necessary-weak-rigid-comprehension-r`) ⇒ Inextensible Comprehension, □Boolean Completeness, □Boolean Completeness (type t), □Countable Boolean Completeness, □Inextensible Comprehension
- **□Weakly Inextensible Comprehension** (`necessary-weakly-inextensible-comprehension-r`) ⇒ Necessity of Arithmetic
- **□Weakly Rigid Power** (`necessary-weakly-rigid-power-r`) ⇒ Necessity of Arithmetic
- **□Weakly Rigid Weak Rigidity** (`necessary-weakly-rigid-weak-rigidity-r`) ⇒ Necessity of Arithmetic, Rigid Power, Weakly Rigid Power, □Rigid Power, □Weakly Rigid Power
- **□Well-Ordering** (`necessary-well-ordering-r`) ⇒ Necessity of Arithmetic

## 6. Deliberately deferred

`topics/classicism/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/classicism/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/classicism/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Worked on a question without settling it? Put what you tried and what would settle it in the conjecture's `notes`; that alone earns it a bronze lynchpin star. Say in the notes whether you think it deserves silver or gold, by importance and difficulty, and why. Only a human sets `tier: silver` or `tier: gold`; an agent never does.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
