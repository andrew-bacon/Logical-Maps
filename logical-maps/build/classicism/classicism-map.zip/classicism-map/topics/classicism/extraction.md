# Classicism: import coverage

Source: Andrew Bacon and Cian Dorr, *Classicism*, in Fritz and Jones (eds),
*Higher-Order Metaphysics*, Oxford University Press, 2024, pp. 109–190. The
import was made from the draft dated 16 May 2023, 87 pages, which does not
differ materially from the published version; locators refer to that draft,
including its footnotes.

The import includes the positive extension principles in §§1.4–2.6,
distinguished type instances used by the paper, boxed variants used in its
connections, the Gallin comparison, the choice decomposition, and the
pure/signature variants of the maximalist schemata. The named background
consequences in §1.5 have separate nodes. The defining rules of H and C,
Boolean identities, and the machinery of action-model semantics remain
part of the framework rather than separate extension nodes.

| Source | Connections recorded |
| --- | --- |
| §1.4, pp. 15–16 | Fregean Axiom, Extensionality, Functionality |
| §1.5, pp. 16–19 | K, T, 4, NI, CBF, Broad Necessitism, Intensionality, Modalized Functionality |
| Proposition 2.1, pp. 20–21 | Functionality, Tractarianism and BF equivalence |
| Proposition 2.2, p. 22 | ND, ND at t, 5 and B equivalence |
| Propositions 2.3–2.4, pp. 22–23 | Boxed ND implies BF; ND and BF imply boxed ND |
| Propositions 2.5–2.7, pp. 25–26 | C5, completeness, atomicity and Actuality connections |
| §2.2, p. 27 | Reported No Pure Contingency theorem; proof pending |
| Propositions 2.8–2.10, pp. 29–30 | Rigid Comprehension, completeness and Actuality |
| Propositions 2.11–2.12, p. 30 | Rigid Comprehension from boxed Atomicity, completeness and BF; boxed BF |
| §2.3, pp. 31–32 | Functional Choice = Plenitude + Relational Choice |
| Propositions 2.13–2.16, pp. 32–33 | Plenitude, ND, Actuality, completeness and Rigid Comprehension |
| §2.3, p. 33 | Boxed equivalences and C5 + Atomicity package |
| §§2.4–2.5, pp. 35–40 | Distinctness Maximalism, Possibility Maximalism, Separated Structure, Witnessed Possibility, Logical Necessity |
| §2.6, pp. 41–42 | Maximalist incompatibilities, Possibility+, Strong Possibility |
| §3.5, pp. 59–61 | Full action-model examples and pure-sentence B |
| Appendix D, Proposition D.5, pp. 74–79 | Eight finite-support packages and two multiple-object examples |
| Theorem 3.26; Appendix E, pp. 80–83 | Coalesced-sum models and distinctness-preserving collapse |

Model descriptions give the source construction and the point at which
the properties hold. The map uses the paper's relational type system, so
the source constructions apply directly. One explicitly described full
Henkin model over a singleton individual domain is credited as an original
specialization of the standard construction. So are the two full one-object
action models over the group of all permutations of an infinite set (§3.5), with
the natural action on the individuals and with one individual; they witness
the joint consistency of □ND, the Axiom of Infinity at type t and □Relational
Choice. The singleton-root coalesced
model retains a separate pending obligation to interpret the map's fixed
nonlogical signature; its pure-language source construction is proved.

Two reported results lack proofs in this draft: the Goodsell–Yli-Vakkuri
No Pure Contingency result (p. 27) and Goodsell's incompatibility of
Maximalist Classicism with Rigid Comprehension (p. 41). Their records retain
the attribution and claim with pending verification status. No claim is
made that the source authors regarded them as conjectures.

The formalized statement of Proposition 2.15 uses the intended second
disjunct with the output variable equal to top; its record identifies the
printed variable typo. Proposition 2.11 is recorded as a conjecture since 28 September 2026: the
proof in note 42 has two gaps (see the record). In that proof, Actuality is obtained
from Proposition 2.7; note 42's reference to Proposition 2.6 would require
an extra C5 premise. The question in note 93 about BF + Atomicity without
Actuality is not imported as open: Proposition 2.7 already rules it out.

Fundamental Possibility (§2.5, pp. 39–40) and the principle that every
individual is fundamental (§2.6, n. 60, p. 41) are not imported. Both use
the fundamentality predicate $\operatorname{Fun}$, a nonlogical constant,
so they lie outside the map's logical vocabulary; the connection recorded
from n. 60 went with them.

Type-system comparison variants and their specialization arrows are omitted.
All schemata use the fixed relational type system; restrictions on
particular type parameters remain explicit.
The inference engine treats each schema as a proposition; it does not
perform type substitution automatically. The useful recorded instances
and their connecting results make those steps explicit.

## Arithmetic is Necessary (Goodsell, 2024 draft)

Source: Zachary Goodsell, *Arithmetic is Necessary*, draft dated 5 June 2024,
28 pages. Its logic HKC is H plus K plus Countable Boolean Completeness,
which C extends, so its theorems transfer to the map with the type $\nu$
instantiated as $(\sigma t)t$ at every type $\sigma$ (see Background; until 16 October
2026 the map fixed $\sigma=e$).

| Source | Connections recorded |
| --- | --- |
| §3, Definitions 1 and 6, pp. 7–8, 13 | Countable Boolean Completeness; Boolean Completeness restricts to it |
| §4, Definitions 3–5 and 8, pp. 11–13, 19 | The arithmetical vocabulary, $I$, arithmetical sentences |
| §5, Lemmas 2–8 and Theorem 9, pp. 14–21 | Countable Boolean Completeness implies the Necessity of Arithmetic |
| §6, Theorem 11, pp. 24–26 | Possibility Maximalism (pure) is incompatible with the Necessity of Arithmetic, hence with Countable and full Boolean Completeness and with Rigid Comprehension |

Theorems 10 (arithmetical signatures) and the truth-predicate extension of
§5.3 are not imported. The consistency of C with $I$, assumed in the
source's n. 14, is witnessed on the map by the full Henkin model with a
countably infinite individual domain.

## Logical Combinatorialism (Bacon, 2020)

Source: Andrew Bacon, *Logical Combinatorialism*, *Philosophical Review*
129(4), 2020, pp. 537–589, read directly on 22 September 2026. Its
background system HFE is contained in C, and its schemata are taken in the
map's relational type system (see Background).

| Source | Connections recorded |
| --- | --- |
| §2, pp. 544–547 | Logical Necessity (already recorded), with direct locators |
| §3, pp. 550–557 | Modal Freedom (signature Σ) from Logical Necessity; No Brute Necessities as an alias of Witnessed Possibility; nn. 29–30 on the failure of ND and B |
| §4, pp. 560–565 | Logical Necessity ⇒ Separated Structure; General Separated Structure and its equivalence with Separated Structure; Possibly Witnessed Possibility as a further equivalent |
| §4, p. 568 and n. 53 | Independence (signature Σ) from Separated Structure |
| Appendix A.2–A.3, pp. 580–587 | The glued full action model over the free monoid, in a thread-individual and a singleton-individual variant, proved on 22 September 2026 with a write-up that supplies the unproved Theorem A.8 from the 2024 book's coalesced sums |

Not imported, following Zachary Goodsell's decision of 21 September 2026
that the map's vocabulary is the logical constants together with the
constants of $\Sigma$: everything stated with Bacon's predicates
$\operatorname{Fun}_\sigma$ and $\operatorname{Pure}_\sigma$, namely
Quantified Logical Necessity and its necessitation, Quantified Separated
Structure, Fundamental Independence and Completeness, Purity, Pure
Application, the purity of purity and of fundamentality, the
fundamentality-quantified forms of Logical Necessity, Witnessed Possibility
and Modal Freedom, the §3 consequences for fundamental entities, and the
propositional liar of n. 60; likewise Classicism's Fundamental Possibility
and its n. 58 consequence about converses. Also not imported: the
fine-grained converse-uniqueness principle (nn. 45–46), Russell and
Hawthorne's set-theoretic Pattern and the inaccessible-order-type example
(§3, pp. 551–553), Structure, which is inconsistent (§4, p. 558), and
Melianism (§4, p. 571). The glued models' interpretation of
$\operatorname{Pure}$ and $\operatorname{Fun}$ (Appendix A.3) is not
recorded either; the models are recorded for the pure and signature
principles only.

## A Philosophical Introduction to Higher-Order Logics (Bacon, 2024)

Source: Andrew Bacon, *A Philosophical Introduction to Higher-Order Logics*,
Routledge, 2024, chapters 8 and 18, read directly on 22 September 2026.
Locators are the book's page numbers.

| Source | Connections recorded |
| --- | --- |
| §8.2, pp. 164–171 | Strong Leibniz Biconditionals and their necessitation; Weak Leibniz Biconditionals as an alias of Atomicity; SL ⇒ Atomicity, Atomicity + BF ⇒ SL, their boxed forms, and □SL + Rigid Comprehension ⇒ □BF (type t) (Theorem 8.2) |
| §18.1, §18.3, §18.6 | Modal models, standard models and coalesced sums, used to prove the glued free-monoid models of Logical Necessity |

The rest of chapter 8 restates material already imported from Classicism.
Chapter 18's coherence results (Corollary 18.2, Proposition 18.8,
Corollaries 18.3–18.4, Propositions 18.9–18.11) concern maximalizations of
extensions of C other than C itself; whether to record them as relativized
Possibility Maximalism principles awaits a decision.

## Deferred model verdicts: Tame Rigidity and Intensional Choice (recorded 3 October 2026)

**4 October 2026 (Claude Fable 5.1, at Cian Dorr's direction).** The collapse lemma is now the
topic's general argument `arguments/intensional-choice-collapse.yaml`, under the conditions
`symmetric-domains`, `construction-individuals` and `collapse-onto-point`; the six symmetric models
meet it as before, and so do the new symmetry-constrained full models
(`groups/symmetry-constrained-full.yaml`), finite models in which Intensional Choice fails while
Actuality, Atomicity, Boolean Completeness and Rigid Comprehension hold. qualitative-contrast's
positive verdict and qualitative-links' failure (via the constant pair property) are worked out in
the transcript of 3 October and not yet recorded.

The verdicts deferred here on 2 and 3 October, until the model records' new format landed, are now
recorded; the arguments, not yet checked by a human, moved into the records and are no longer kept
here (see git history before 3 October for the notes). Tame Rigidity: the finite-support group's
argument `tame-rigidity` under the condition `arrows-finitely-determined` (truncations, dyadic
roundings, truncated shifts), and the result `c5-implies-necessary-tame-rigidity`. Intensional
Choice: the collapse lemma as the symmetric group's argument `intensional-choice` under
`collapse-onto-point`, at the base individuals only; and, from a Classicism session of the same
day, the general argument `intensional-choice-well-ordering` under `codomain-intensions` (ideally
full and full models), the coalesced group's `intensional-choice-component`, and the own arguments
of the Boolean-valued, ultralimit-fork, all-finite coalesced, qualitative-links and
qualitative-contrast models. Open: Intensional Choice in the symmetric models' one-individual
variants.

## Deferred model verdicts: Rigid Power (3 October 2026)

**Done, 4 October 2026 (Claude Fable 5.1, at Cian Dorr's direction).** The argument below is the general
argument `arguments/rigid-power-tight.yaml`, under the condition `rigid-haecceity-disjunctions`, met by
the full action models and the symmetry-constrained full models. The finite-support group has a shared
argument `rigid-power` under its condition `uniformly-pinned-rigidity`, met by truncations (eventual
constancy) and by monotone-maps and identity-or-collapse (the jump-map lemma). Dyadic roundings and truncated shifts
followed the same day by own arguments (finitely determined arrows give tightness, and the composition laws
$f_n\circ f_m=f_n$, $k_{n-m}\circ k_m=k_n$ give the closure). Open: the surjective finite-support monoids
monotone-surjections and identity-or-collapse-surjections, the two-object finite-support models, the symmetric models,
the coalesced roots and the ultralimit fork.

**To do.** Record `rigid-power-r` and `necessary-rigid-power-r` as satisfied, in the
new model-record format (an argument of the full action models' group would cover them), in `full-idempotent-monoid`,
`full-two-object-chain` and `full-two-object-retract`, with the argument below. (Moved here from the `classicism-edits`
worktree on 3 October 2026, after the new format had landed.)
The engine already derives both in the other full models, through C5 or
□BF + □Atomicity + □Rigid Comprehension.

**Argument** (Claude Opus 5.5 (Anthropic), 3 October 2026; not yet checked by a
human). In a full action model, write $X_0(S)_k:=k\cdot S$. At any object,
$X_0(S)$ is in the domain, so a relation $Y$ is weakly rigid iff $Y=X_0(Y_1)$.
Every such $Y$ is rigid, since $(h\cdot Y)_k=k\cdot(h\cdot Y_1)$. So the rigid
relations are exactly the $X_0(S)$. Moreover $X_0(T)\le X_0(S)$ iff $T\subseteq S$.
For rigid $F=X_0(S)$ and $P:=\lambda X\, .\,\operatorname{Rigid}(X)\land X\le F$:
- at an arrow $k$, $P_k=\{X_0(T'):T'\subseteq k\cdot S\}$;
- transport gives $k\cdot P_1=\{X_0(k\cdot T):T\subseteq S\}$;
- these coincide, because the image map $T\mapsto k\cdot T$ from subsets of $S$ to
  subsets of $k\cdot S$ is onto.

So $P=X_0(P_1)$, and $P$ is rigid. The same holds at every object, so both forms of
Rigid Power hold in every full action model.

## Could the truths of mathematics have been different? (Bacon, 2025 draft)

Read directly on 19 October 2026 (Claude Fable 5.1), from the draft of 9 October 2025 with its
separately paginated appendix; the paper is published in Philosophical Review 135(3), 2026. Its
background logic $\mathrm H\Box$ is weaker than C; everything imported is read into C, where its
Leibniz Biconditionals (§5, p. 23; Figure 2), with world relations in the unboxed sense, are the
map's Atomicity, now carrying that alias.

| Source | Recorded |
| --- | --- |
| Theorem 4.4, p. 19; Appendix C.1, Proposition C.2, Lemma C.1, Theorem C.1 | `c5-implies-necessity-of-arithmetic`, transposed to the map's numbers at each type; it proves □A ∨ □¬A outright. Formalized: the steps of the induction are derived shallow theorems (`lean/Classicism/Results/SentenceSchemas/Arithmetic.lean`) and the induction over arithmetical sentences composes their derivations (`ArithmeticMeta.lean`) |
| Appendix C.2, Lemma C.6 | `atomicity-and-rigid-comprehension-imply-rigid-power` and its necessitation; the lemma is run with □ for □_N and its conclusion turned into Rigid Power by Tame Rigidity |
| §6, Intensional Choice; Theorem 6.1, Conjecture 6.1 | Intensional Choice was imported on 3 October 2026. Mathematical Possibilism joined the map on 23 October 2026 as `forcing-possibilism` (Forcing Possibilism, with Bacon's name as an alias), through Bacon's own contribution of the lottery-algebra model and the modalized-domain models (*Modalized Domains on Possibility Frames*, Bacon and Claude Opus 5.5, draft of 20 October 2026, in `papers.yaml`); that model, with □Rigid Comprehension and □Intensional Choice, settles Conjecture 6.1 in C. Theorem 6.1 (□RC, Intensional Choice and the principle make CH contingent) is not yet recorded: its proof is not in the draft or the handout |
| Appendix B.2, Theorem 5.1 | The Boolean-valued model, imported earlier (`full-boolean-valued-atom-and-atomless`) |

Not imported: the Necessity of Analysis (Theorem 5.2, Corollary 5.1, Appendix C.2 beyond Lemma C.6),
the map having no principle for analysis; Theorem 4.1 (arithmetical contingency in C, Appendix B.1),
whose model the map does not need; Theorem 4.3 (second-order logic); n. 59, that S5 with □Rigid
Comprehension gives the Leibniz Biconditionals, which the engine already derives from
`necessary-rigid-comprehension-r-implies-necessary-actuality` and
`c5-and-necessary-actuality-imply-atomicity`; Conjecture 5.1, answered by Barton and Goodsell below.

## Continuum Contingency (Barton and Goodsell, 2026 draft)

Read directly on 19 October 2026 (Claude Fable 5.1), from the draft of 14 October 2026. Its logic
CR∞ is C with □Rigid Comprehension and an axiom of infinity, CRC∞ adds □Relational Choice, and its
Atomicity is the map's Atomicity (type t). Its models are action models in the full simple type
hierarchy; their restrictions to the map's relational types are recorded.

| Source | Recorded |
| --- | --- |
| §8, Definition 1, Lemmas 11–19; Theorem 20; Theorem 21 | `stitched-cohen-extension`, the simplest instance: trivial group, the canonical extensional model, Cohen forcing. Rigid Power fails with □Rigid Comprehension, □Relational Choice, □Atomicity (type t) and □Strong Leibniz (type t) |
| Theorems 3–7 (arithmetic and analysis in CR∞) | The Necessity of Arithmetic in CR∞ is derivable on the map through Countable Boolean Completeness; the analytical results concern no principle of the map |

Not imported: Theorem 9 (the coin-toss theorem) and Theorem 22 (Recombination with continuum
contingency), Recombination not being a principle of the map; Corollary 23, that CRC∞ is consistent
with the failure of Atomicity (type t), Christopher Sun's conjecture, which `symmetric-collapse-pair`
already witnesses for □Rigid Comprehension; Theorem 24 and §10 (iterated contingency). Deferred: the
Theorem 22 model as a record, which would add Recombination if that principle is ever recorded, and
the finite-group variants of Theorem 21.

