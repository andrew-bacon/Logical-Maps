# ⊤ ⇒ 4 (≠⊥)

<p class='cert'>Result — Source: Misc.; produced by Codex (GPT-6), prompted by Zachary Goodsell, 13 September 2026; recorded by Codex (GPT-6), prompted by Zachary Goodsell, manuscript transcription.</p>

## Premises

- $\top$

## Conclusion

- **4 (≠⊥).** For every $p, (p \ne \bot ) \ne \bot$ implies $p \ne \bot$.

## Proof

Suppose $\neg ((p\ne \bot )=\bot )$ and $p=\bot$. Substitution gives $(p\ne \bot )=(\bot \ne \bot )=\bot$, where the last identity follows from reflexivity and assumption-free intensionality. This is a contradiction. Hence $p\ne \bot$; discharge and generalize.

## Notes

Informal proof; no independent checker or Lean verification.

## Sources

- **Codex connecting proof, 13 Sep 2026** — Codex (GPT-6), connecting proof recorded 13 September 2026 in ii-implies-four-distinct-from-bottom.
- **Possibility in Intuitionistic Higher-Order Logic** — Zachary Goodsell, Possibility in Intuitionistic Higher-Order Logic (21 August 2026), §3.1, definition of $\ne \bot , p. 8$; §3.2, footnote 5, p. 10.

<p class='cert'>Record: <code>topics/intuitionisticism/results/ii-implies-four-distinct-from-bottom.yaml</code></p>
